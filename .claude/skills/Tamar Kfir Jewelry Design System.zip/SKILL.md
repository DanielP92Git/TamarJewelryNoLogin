---
name: tamar-kfir-jewelry-design
description: Use this skill to generate well-branded interfaces and assets for Tamar Kfir Jewelry, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

**Working in a non-React codebase (e.g. the live vanilla-JS site)?** The React files under `components/`/`ui_kits/` are prototyping recreations — do NOT paste their JSX into a vanilla site. Use this system as **tokens + guidelines + assets**: link `styles.css` and use the `--tk-*` CSS variables directly, read each component's `.prompt.md`/`.jsx` as a spec, and re-express it in the page's own HTML/CSS idiom. See the "Using this in a non-React codebase" section of `README.md`.

**Scope:** this is a reference/spec, not a map of how the live code is wired (the site does not currently use the `--tk-*` tokens). Use it for brand values and NEW elements/components. Do NOT refactor existing working code to adopt these tokens unless the user explicitly asks. When the system and the live code disagree, the live code wins unless the user is deliberately converging on it.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick map
- `README.md` — brand story, content voice, visual foundations, iconography, full manifest. **Start here.**
- `styles.css` — the one stylesheet to link; `@import`s all tokens + fonts.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css` (CSS custom properties, all prefixed `--tk-`).
- `components/` — React primitives (Button, IconButton, Badge, PriceTag, Input, QuantityStepper, ProductCard, CategoryTile, NavBar, Footer). Each has a `.prompt.md` with usage.
- `ui_kits/storefront/` — interactive shop recreation (home → category → product → cart).
- `guidelines/` — foundation specimen cards.
- `assets/` — logo, icons, hero/category/product imagery.

## House style in one breath
Gallery-white UI, one warm **gold `#c5a572`** accent, warm-charcoal **ink `#1f2937`** actions. **Montserrat** everywhere with wide letter-spacing on UPPERCASE chrome; Cormorant serif for titles & headings; Rubik for Hebrew. Sharp corners (pill only for the hero CTA), whisper-soft shadows, `-3px` hover lift, calm short transitions. Let the colourful handmade photography carry the personality.

**Bilingual:** wrap any Hebrew surface in `dir="rtl"` — the design system remaps its font tokens to Rubik for that subtree automatically (no per-component work). RTL also mirrors the flex/grid layouts.
