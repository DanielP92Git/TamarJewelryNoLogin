// Tamar Kfir Jewelry — sample storefront catalogue (demo data)
// Photography is the brand's own; copy mirrors the real product voice.
window.TK_DATA = {
  categories: [
    { slug: 'crochet', name: 'Crochet Necklaces', image: '../../assets/categories/crochet.webp' },
    { slug: 'hoops', name: 'Hoop Earrings', image: '../../assets/categories/hoops.webp' },
    { slug: 'dangle', name: 'Dangle Earrings', image: '../../assets/categories/dangle.webp' },
    { slug: 'necklaces', name: 'Necklaces', image: '../../assets/categories/necklaces.webp' },
  ],
  products: [
    {
      id: 'p1', category: 'crochet', name: 'True Colors',
      price: 450, image: '../../assets/products/crochet-01.jpg', badge: 'Handmade',
      gallery: ['../../assets/products/crochet-01.jpg', '../../assets/products/crochet-02.jpg'],
      desc: 'A multi-strand necklace crocheted with metallic thread and a riot of glass beads — blues, reds and golds woven together so no two sit the same way twice.'
    },
    {
      id: 'p2', category: 'crochet', name: 'Blue Moon',
      price: 120, image: '../../assets/products/crochet-02.jpg',
      gallery: ['../../assets/products/crochet-02.jpg', '../../assets/products/crochet-01.jpg'],
      desc: 'Soft indigo and teal beads crocheted onto a fine metallic strand. Light, layered, and quietly luminous against the skin.'
    },
    {
      id: 'p3', category: 'necklaces', name: 'Howlite Stone',
      price: 120, image: '../../assets/products/necklace-01.jpg',
      gallery: ['../../assets/products/necklace-01.jpg', '../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
      desc: 'A single howlite pendant on a delicate chain — calm, white-veined stone for everyday wear.'
    },
    {
      id: 'p4', category: 'necklaces', name: 'Green Boulevard',
      price: 150, original: 180, image: '../../assets/products/necklace-02.jpg', badge: 'Sale',
      gallery: ['../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
      desc: 'Layered green-stone strands that catch the late afternoon light. Adjustable clasp.'
    },
    {
      id: 'p5', category: 'necklaces', name: 'Jade Whisper',
      price: 165, image: '../../assets/products/necklace-jade.jpg',
      gallery: ['../../assets/products/necklace-jade.jpg', '../../assets/products/necklace-01.jpg'],
      desc: 'Smooth jade beads strung by hand, finished with a small gold-fill accent.'
    },
    {
      id: 'p6', category: 'hoops', name: 'Crystal Hoop',
      price: 96, original: 120, image: '../../assets/products/hoop-02.jpg', badge: 'Sale',
      gallery: ['../../assets/products/hoop-02.jpg', '../../assets/products/hoop-01.jpg'],
      desc: 'Slim gold-fill hoops threaded with amethyst and aqua crystal drops. Feather-light to wear.'
    },
    {
      id: 'p7', category: 'hoops', name: 'Morning Hoop',
      price: 90, image: '../../assets/products/hoop-01.jpg',
      gallery: ['../../assets/products/hoop-01.jpg', '../../assets/products/hoop-03.jpg'],
      desc: 'Everyday hoops with a scatter of warm-toned beads. Made to layer with your other favourites.'
    },
    {
      id: 'p8', category: 'hoops', name: 'Garden Hoop',
      price: 110, image: '../../assets/products/hoop-03.jpg',
      gallery: ['../../assets/products/hoop-03.jpg', '../../assets/products/hoop-04.jpg'],
      desc: 'A fuller hoop wrapped in mixed glass beads — a little colour for grey mornings.'
    },
    {
      id: 'p9', category: 'dangle', name: 'Sweet Drop',
      price: 90, image: '../../assets/products/earring-01.jpg',
      gallery: ['../../assets/products/earring-01.jpg', '../../assets/products/earring-02.jpg'],
      desc: 'Petite beaded drops that sway with you. The kind of earring you forget you are wearing.'
    },
    {
      id: 'p10', category: 'dangle', name: 'ALE Dangle',
      price: 240, image: '../../assets/products/earring-02.jpg', badge: 'Handmade',
      gallery: ['../../assets/products/earring-02.jpg', '../../assets/products/earring-01.jpg'],
      desc: 'Statement dangles in faceted stone and metallic thread — designed to be noticed.'
    },
  ],
};
