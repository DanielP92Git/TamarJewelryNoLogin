# Storefront UI Kit — Tamar Kfir Jewelry

An interactive, click-through recreation of the handmade-jewelry storefront, composed entirely from the design-system components.

## Run
Open `index.html` (English / ILS) or `index-he.html` (Hebrew / RTL). Each loads `../../styles.css`, the compiled `../../_ds_bundle.js`, its demo catalogue, and its screens.

## Flow
- **Home** — transparent `NavBar` over the lifestyle hero with the brand tagline *"One of a kind in mind"* and a gold outline CTA, then a 2-up `CategoryTile` grid and a row of featured `ProductCard`s.
- **Category** — solid `NavBar`, photographic category header, and a product grid filtered by collection. Click any card to open the product.
- **Product modal** — thumbnail rail, large image, serif title, `PriceTag`, description, `QuantityStepper`, and a dark Add-to-Cart `Button`.
- **Cart drawer** — slides in from the right; line items with per-item `QuantityStepper` + remove, running subtotal, and checkout.

## Files
| File | Purpose |
|---|---|
| `index.html` | English shell: loads React, the DS bundle, data and app. Tagged `@dsCard` + `@startingPoint`. |
| `index-he.html` | Hebrew / RTL shell — `dir="rtl"`, Rubik typography, cart drawer slides from the left. |
| `data.js` / `data-he.js` | `window.TK_DATA` / `TK_DATA_HE` — demo categories + products. |
| `app.js` / `app-he.js` | All screens (`Home`, `CategoryView`, `ProductModal`, `CartDrawer`) + the `App` shell. `.js` (not `.jsx`) so the DS compiler does not bundle them; the browser Babel transforms them by `type`. |

## Notes
This is a visual/interaction recreation, not production code — cart state is in-memory, checkout is non-functional. The English kit shows the ILS (₪) surface; `index-he.html` demonstrates the full Hebrew RTL mirror (Rubik type, mirrored layout, Hebrew copy) of the bilingual live store.
