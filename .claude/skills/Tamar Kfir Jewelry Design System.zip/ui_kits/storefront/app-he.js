/* Tamar Kfir Jewelry — Storefront UI kit (Hebrew / RTL)
   Mirror of app.js with Hebrew copy, dir="rtl", Rubik typography,
   and the cart drawer sliding from the left. */
let NavBar, Footer, CategoryTile, ProductCard, PriceTag, Badge, Button, QuantityStepper;
const { useState } = React;

const LOGO = '../../assets/logo/tamar-logo.webp';
const HERO = '../../assets/imagery/hero-main.webp';
const NAV_LINKS = ['בית', 'חנות', 'סדנת תכשיטים', 'אודות', 'צרי קשר'];
const ADD = 'הוסיפי לסל';

/* ---------------- Home ---------------- */
function Home({ onCategory, onProduct }) {
  const featured = window.TK_DATA_HE.products.slice(0, 4);
  return (
    <div>
      <section style={{ position: 'relative', height: '78vh', minHeight: 540, overflow: 'hidden' }}>
        <img src={HERO} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 15%' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.25), rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.35))' }} />
        <div style={{ position: 'relative', zIndex: 2 }}>
          <NavBar logoSrc={LOGO} links={NAV_LINKS} active="בית" mode="transparent" cartCount={window.__cartCount || 0} onCart={window.__openCart} onNavigate={() => {}} />
        </div>
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: '14%', zIndex: 2, textAlign: 'center', color: '#fff' }}>
          <p style={{ margin: '0 0 1.6rem', fontWeight: 300, fontSize: 'clamp(2rem, 3.4vw, 3rem)', letterSpacing: '0.04em', textShadow: '0 3px 15px rgba(0,0,0,0.6)' }}>
            אחת ויחידה
          </p>
          <Button variant="outline" size="lg" onClick={() => document.getElementById('shop').scrollIntoView({ behavior: 'smooth' })}>
            לגלות את הקולקציה
          </Button>
        </div>
      </section>

      <section id="shop" style={{ maxWidth: 1100, margin: '0 auto', padding: '5rem 2rem 2rem' }}>
        <SectionHead eyebrow="קולקציות" title="קנו לפי קטגוריה" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: '2.5rem' }}>
          {window.TK_DATA_HE.categories.map((c) => (
            <CategoryTile key={c.slug} image={c.image} label={c.name} height={300} onClick={(e) => { e.preventDefault(); onCategory(c.slug); }} />
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '4rem 2rem 5rem' }}>
        <SectionHead eyebrow="חדש ואהוב" title="פריטים נבחרים" />
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 28, marginTop: '2.5rem' }}>
          {featured.map((p) => (
            <ProductCard key={p.id} image={p.image} title={p.name} price={p.price} original={p.original} badge={p.badge} addLabel={ADD}
              onAdd={() => window.__addToCart(p)} onClick={() => onProduct(p)} />
          ))}
        </div>
      </section>

      <Footer columns={HE_FOOTER} copyright="© 2024 תמר כפיר תכשיטים. כל הזכויות שמורות." onNavigate={() => {}} />
    </div>
  );
}

const HE_FOOTER = [
  { heading: 'חנות', links: ['שרשראות', 'שרשראות סרוגות', 'עגילי חישוק', 'עגילים תלויים'] },
  { heading: 'שירות לקוחות', links: ['משלוח וביטול', 'צרי קשר'] },
  { heading: 'אודות', links: ['סדנת תכשיטים', 'אודותי'] },
];

/* ---------------- Category ---------------- */
function CategoryView({ slug, onBack, onProduct }) {
  const cat = window.TK_DATA_HE.categories.find((c) => c.slug === slug);
  const items = window.TK_DATA_HE.products.filter((p) => p.category === slug);
  return (
    <div>
      <NavBar logoSrc={LOGO} links={NAV_LINKS} active="חנות" mode="solid" cartCount={window.__cartCount || 0} onCart={window.__openCart} onNavigate={(l) => { if (l === 'בית') onBack(); }} />
      <div style={{ position: 'relative', height: 280, overflow: 'hidden' }}>
        <img src={cat.image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 35%' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.28)' }} />
        <h1 style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: 0, color: '#fff', fontWeight: 400, fontSize: '2.2rem', letterSpacing: '0.08em', textShadow: '0 2px 14px rgba(0,0,0,0.5)' }}>
          {cat.name}
        </h1>
      </div>
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '2.5rem 2rem 1rem' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--tk-text-muted)', fontSize: '0.8rem', letterSpacing: '0.04em' }}>
          חזרה לדף הבית →
        </button>
      </div>
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '1.5rem 2rem 5rem', display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 28 }}>
        {items.map((p) => (
          <ProductCard key={p.id} image={p.image} title={p.name} price={p.price} original={p.original} badge={p.badge} addLabel={ADD}
            onAdd={() => window.__addToCart(p)} onClick={() => onProduct(p)} />
        ))}
      </div>
      <Footer columns={HE_FOOTER} copyright="© 2024 תמר כפיר תכשיטים. כל הזכויות שמורות." onNavigate={() => {}} />
    </div>
  );
}

/* ---------------- Product Modal ---------------- */
function ProductModal({ product, onClose }) {
  const [active, setActive] = useState(0);
  const [qty, setQty] = useState(1);
  if (!product) return null;
  const gallery = product.gallery || [product.image];
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'var(--tk-overlay)', zIndex: 1055, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', width: '92%', maxWidth: 960, maxHeight: '92vh', display: 'flex', position: 'relative', boxShadow: 'var(--tk-shadow-modal)', overflow: 'hidden' }}>
        <button onClick={onClose} aria-label="סגירה" style={{ position: 'absolute', top: 16, left: 18, zIndex: 5, background: 'none', border: 'none', fontSize: 28, lineHeight: 1, color: 'var(--tk-ink)', cursor: 'pointer' }}>×</button>
        <div style={{ width: 96, flex: 'none', padding: '20px 10px', display: 'flex', flexDirection: 'column', gap: 12, background: '#fff', overflowY: 'auto' }}>
          {gallery.map((g, i) => (
            <button key={i} onClick={() => setActive(i)} style={{ width: 76, height: 76, padding: 0, border: i === active ? '1px solid var(--tk-gold)' : '1px solid var(--tk-border)', background: 'var(--tk-surface)', cursor: 'pointer', overflow: 'hidden' }}>
              <img src={g} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </button>
          ))}
        </div>
        <div style={{ flex: '1.4', background: 'var(--tk-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', minWidth: 0 }}>
          <img src={gallery[active]} alt={product.name} style={{ maxWidth: '100%', maxHeight: '92vh', objectFit: 'contain', display: 'block' }} />
        </div>
        <div style={{ flex: '1', maxWidth: 340, padding: '46px 34px 28px', display: 'flex', flexDirection: 'column', overflowY: 'auto', textAlign: 'right' }}>
          {product.badge && <div style={{ marginBottom: 14 }}><Badge variant={product.badge === 'מבצע' ? 'gold' : 'soft'}>{product.badge}</Badge></div>}
          <h2 style={{ margin: '0 0 6px', fontWeight: 500, fontSize: '1.7rem', color: 'var(--tk-ink)', lineHeight: 1.2 }}>{product.name}</h2>
          <div style={{ marginBottom: 20 }}><PriceTag amount={product.price} original={product.original} size="lg" align="right" /></div>
          <p style={{ margin: '0 0 28px', fontSize: '0.98rem', lineHeight: 1.85, color: 'var(--tk-text-soft)' }}>{product.desc}</p>
          <div style={{ marginTop: 'auto', borderTop: '1px solid var(--tk-border)', paddingTop: 20, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <span style={{ fontSize: '0.78rem', color: 'var(--tk-text-muted)' }}>כמות</span>
              <QuantityStepper value={qty} min={1} max={9} onChange={setQty} />
            </div>
            <Button variant="primary" fullWidth onClick={() => { window.__addToCart(product, qty); onClose(); }}>{ADD}</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Cart Drawer (slides from the LEFT for RTL) ---------------- */
function CartDrawer({ open, items, onClose, onQty, onRemove }) {
  const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1056, pointerEvents: open ? 'auto' : 'none' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)', opacity: open ? 1 : 0, transition: 'opacity 0.3s ease' }} />
      <aside style={{ position: 'absolute', top: 0, left: 0, height: '100%', width: 420, maxWidth: '90vw', background: '#fff', boxShadow: '8px 0 30px rgba(0,0,0,0.12)', transform: open ? 'translateX(0)' : 'translateX(-100%)', transition: 'transform 0.35s var(--tk-ease)', display: 'flex', flexDirection: 'column', textAlign: 'right' }}>
        <div style={{ padding: '24px 28px', borderBottom: '1px solid var(--tk-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.95rem', fontWeight: 600, color: 'var(--tk-ink)' }}>סל קניות</span>
          <button onClick={onClose} aria-label="סגירה" style={{ background: 'none', border: 'none', fontSize: 26, cursor: 'pointer', color: 'var(--tk-ink)' }}>×</button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 28px' }}>
          {items.length === 0 && <p style={{ color: 'var(--tk-text-muted)', fontSize: '0.95rem', marginTop: 40, textAlign: 'center' }}>הסל שלך ריק.</p>}
          {items.map((it) => (
            <div key={it.id} style={{ display: 'flex', gap: 16, padding: '20px 0', borderBottom: '1px solid var(--tk-border-light)' }}>
              <div style={{ width: 80, height: 80, flex: 'none', background: 'var(--tk-surface)', overflow: 'hidden' }}>
                <img src={it.image} alt={it.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                  <span style={{ fontSize: '1rem', color: 'var(--tk-text)', fontWeight: 500 }}>{it.name}</span>
                  <span style={{ fontSize: '0.92rem', fontWeight: 600, whiteSpace: 'nowrap' }}>₪{it.price * it.qty}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <QuantityStepper value={it.qty} min={1} max={9} width={96} onChange={(n) => onQty(it.id, n)} />
                  <button onClick={() => onRemove(it.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.8rem', color: 'var(--tk-text-faint)', textDecoration: 'underline', textUnderlineOffset: 3 }}>להסיר</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding: '22px 28px 26px', borderTop: '1px solid var(--tk-border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: '0.95rem', color: 'var(--tk-text)' }}>
            <span>סכום ביניים</span><span style={{ fontWeight: 600 }}>₪{subtotal}</span>
          </div>
          <p style={{ margin: '0 0 18px', fontSize: '0.8rem', color: 'var(--tk-text-muted)' }}>המשלוח מחושב בתשלום.</p>
          <Button variant="primary" fullWidth disabled={items.length === 0}>המשך לתשלום</Button>
        </div>
      </aside>
    </div>
  );
}

/* ---------------- App shell ---------------- */
function App() {
  const [route, setRoute] = useState({ name: 'home' });
  const [modal, setModal] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState([]);

  const addToCart = (p, qty = 1) => {
    setCart((prev) => {
      const found = prev.find((x) => x.id === p.id);
      if (found) return prev.map((x) => x.id === p.id ? { ...x, qty: x.qty + qty } : x);
      return [...prev, { id: p.id, name: p.name, price: p.price, image: p.image, qty }];
    });
    setCartOpen(true);
  };
  const cartCount = cart.reduce((s, it) => s + it.qty, 0);
  window.__addToCart = addToCart;
  window.__openCart = () => setCartOpen(true);
  window.__cartCount = cartCount;

  return (
    <div dir="rtl">
      {route.name === 'home' && <Home onCategory={(slug) => { window.scrollTo(0, 0); setRoute({ name: 'category', slug }); }} onProduct={setModal} />}
      {route.name === 'category' && <CategoryView slug={route.slug} onBack={() => { window.scrollTo(0, 0); setRoute({ name: 'home' }); }} onProduct={setModal} />}
      <ProductModal product={modal} onClose={() => setModal(null)} />
      <CartDrawer
        open={cartOpen}
        items={cart}
        onClose={() => setCartOpen(false)}
        onQty={(id, n) => setCart((prev) => prev.map((x) => x.id === id ? { ...x, qty: n } : x))}
        onRemove={(id) => setCart((prev) => prev.filter((x) => x.id !== id))}
      />
    </div>
  );
}

function SectionHead({ eyebrow, title }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <p style={{ margin: '0 0 10px', fontSize: '0.78rem', letterSpacing: '0.08em', color: 'var(--tk-gold-hover)' }}>{eyebrow}</p>
      <h2 style={{ margin: 0, fontWeight: 600, fontSize: '2rem', color: 'var(--tk-ink)' }}>{title}</h2>
    </div>
  );
}

function tkBoot() {
  if (window.__tkBooted) return;
  const DS = window.TamarKfirJewelryDesignSystem_332983;
  if (!DS || !DS.Button) { setTimeout(tkBoot, 20); return; }
  ({ NavBar, Footer, CategoryTile, ProductCard, PriceTag, Badge, Button, QuantityStepper } = DS);
  window.__tkBooted = true;
  window.__tkRoot = ReactDOM.createRoot(document.getElementById('app'));
  window.__tkRoot.render(<App />);
}
tkBoot();
