# Tamar Kfir Jewelry — Design System

A design system for **Tamar Kfir Jewelry**, a handmade-jewelry e-commerce brand. Each piece is handmade in Jerusalem; the maker is best known for crocheting with metallic threads and combining colour so no two pieces are alike. The visual language is **minimal, quiet, and gallery-like** — Cartier-inspired restraint that lets the colourful, handmade product photography carry all the personality.

This project is the single source of truth for branded interfaces and assets: tokens, fonts, foundation specimens, reusable React components, and a full interactive storefront UI kit.

---

## Sources

Built by reading the brand's production storefront (full-stack e-commerce app):

- **GitHub:** [`DanielP92Git/TamarJewelryNoLogin`](https://github.com/DanielP92Git/TamarJewelryNoLogin) (branch `master`) — frontend SPA (MVC), Node/Express backend, admin dashboard. Bilingual English/Hebrew (RTL) and multi-currency (USD/ILS).
  - Type & colour lifted from `frontend/css/standard-reset.css`, `home-800plus.css`, `categories-800plus.css`, `footer-desktop.css`.
  - A newer Stitch redesign mock (`frontend/code.html`) confirmed the editorial direction (serif headings, gold accent).
  - Logos, icons, hero & product photography copied from `frontend/imgs/**`.

> If you can access the repo, explore it further to design with higher fidelity — especially the View classes in `frontend/js/Views/` (page copy lives in both EJS templates and JS twins) and the category/cart CSS.

Related brand repos by the same owner exist (`tamarJ`, `hewbrewwithtamar`) but were not used.

---

## Content Fundamentals

**Voice — warm, personal, first-person maker.** Copy is written as *"me and my jewelry"*: the artist speaks directly to a *"you"* she wants to feel special. It is intimate and unpolished in the best way — she mentions making jewelry since age 12, finding calm in the craft, selling to *"appreciative customers from all over the world."* Marketing copy stays understated and benefit-light; the story does the selling.

- **Person:** First-person singular (*"I draw inspiration from my city"*), addressing *"you" / "she"*. Never corporate "we".
- **Tone:** Sincere, calm, a little poetic. Product names are evocative and playful — *True Colors, Blue Moon, Golden Slumbers, Lady in Red, I Know I Can Be Colorful* (several riff on song titles).
- **Casing:** UI chrome (nav, buttons, footer headers, category names, eyebrows) is **UPPERCASE with wide letter-spacing**. Headings and body are sentence case. The tagline *"One of a kind in mind"* runs uppercase over the hero.
- **Hebrew:** Full RTL mirror of every page, set in Rubik. Titles like `אודותי` (About), `חנות` (Shop). **Bilingual is first-class:** any `dir="rtl"` subtree automatically remaps the font tokens to Rubik (see `tokens/typography.css`) — components consume `var(--tk-font-*)`, so they switch with zero per-component logic. Wrap a Hebrew surface in `dir="rtl"` and set the page body font to `var(--tk-font-body)`; everything follows.
- **Punctuation/emoji:** No emoji in product or brand copy (flag emoji 🇺🇸🇮🇱 appear only as language switches in one mock — avoid elsewhere). Prices are `₪`-prefixed (ILS) or `$` (USD).
- **Sample lines:** *"A bit about me and my jewelry…"* · *"Each piece is handmade in beautiful, historic Jerusalem."* · *"Handcrafted jewelry pieces that tell your unique story."* · *"Discover the Collection."*

---

## Visual Foundations

**Colour.** A gallery-white UI with **one** brand accent — a warm **gold `#c5a572`** (hover `#bca366`, soft `#cfb577`) used sparingly for outlines, eyebrows, sale prices, and social hovers. Actions are warm-charcoal **ink `#1f2937`** (never pure blue-black) deepening to `#111827`; the footer copyright bar is true black. Text rides a four-step grey ramp (`#333 / #555 / #666 / #999`). Surfaces are white, `#fafafa` (image wells) and `#f5f5f0` (the beige product card). All saturated colour comes from the **product photography**, not the chrome.

**Type.** **Montserrat** does almost everything — thin/light weights (200–300) for hero & display, 400–600 for UI, prices and labels. The signature is **generous letter-spacing**: `0.15em` on nav/footer labels, `0.2em` on buttons, up to `0.25em` on category names and the hero. **Cormorant Garamond** (italic-friendly serif) is the editorial accent for product titles and section heads; **Rubik** sets all Hebrew/RTL. Body copy is `1rem / 1.7`. All fonts load from Google Fonts.

**Backgrounds & imagery.** Full-bleed lifestyle/product photography is the hero of every page — warm natural light, clean white or outdoor backdrops, colourful handmade pieces. No gradients as decoration; gradients appear **only** as bottom *protection scrims* on category tiles (`rgba(0,0,0,.65)→0`) so white labels stay legible. No patterns, no textures, no illustration.

**Layout.** Centered, generous whitespace; section padding `4–5rem`. Home categories in a 2-up grid; product grids flex-wrap centered with `20rem` cards. Header is a fixed `80px` bar — **transparent over the hero** (white nav, inverted logo), **solid white** on inner pages.

**Shape & elevation.** **Sharp corners read as luxury** — dark buttons and the modal are `radius 0`; product cards round a soft `8px`; inputs/thumbnails `4px`. The **only pill** (`50px`) is the gold outline hero button. Shadows are whisper-soft (`0 2px 8px rgba(0,0,0,.08)`, hover `0 4px 12px /.12`); cards and buttons **lift `-3px`** on hover. Borders are `1px` hairlines (`#e5e5e5`).

**Motion & states.** Calm, short transitions (`0.2–0.4s`, ease `cubic-bezier(.4,0,.2,1)`). Entrances fade/slide up. **Hover:** primary buttons darken; cards lift + image zooms `scale(1.04)`; category labels open their letter-spacing to `0.3em`; nav links go to full opacity; social bubbles fill gold. **Press:** no bounce — colour deepens. No infinite/decorative animation.

**Transparency & blur.** Used lightly: hero text sits on photographic scrims; the cart number badge is a translucent white capsule over the hero. No glassmorphism / heavy backdrop-blur.

---

## Iconography

The storefront uses a small set of **flat SVG icons** (FontAwesome-derived line/solid glyphs) plus brand social marks — copied into `assets/icons/`:

- **UI:** `shopping-bag.svg`, `cart.svg`, `menu.svg` (hamburger), `close.svg`, `arrow-up.svg`.
- **Social:** `instagram.svg`, `facebook.svg`, `whatsapp.svg` (WhatsApp is a floating contact button on the live site).
- **Payment:** `stripe.svg`.
- **Logo:** `assets/logo/tamar-logo.webp` — a hand-drawn **TK monogram** above a spaced "TAMAR KFIR" wordmark, black-on-light only (invert to white over photography). `favicon.svg` for tabs.

Icons are monochrome and inherit colour; the cart glyph in `NavBar` is an inline SVG so it can flip white/ink by mode. **No icon font, no emoji** as UI, no Unicode-glyph icons. When you need an icon not in the set, match the existing thin line / simple solid style (FontAwesome or Lucide are close) and flag the addition.

---

## Index / Manifest

**Root**
- `styles.css` — the one entry point consumers link (`@import`s the token + font closure).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`.
- `README.md` (this file) · `SKILL.md` (Agent-Skills wrapper).

**Components** (`window.TamarKfirJewelryDesignSystem_332983.*`)
- `components/core/` — **Button** (primary / gold / outline / ghost), **IconButton** (plain / circle), **Badge** (neutral / gold / soft / outline), **PriceTag** (ILS/USD, sale).
- `components/forms/` — **Input**, **QuantityStepper**.
- `components/commerce/` — **ProductCard**, **CategoryTile**.
- `components/layout/` — **NavBar** (transparent / solid), **Footer**.
- Each directory has a `*.card.html` (@dsCard "Components") and each component a `.d.ts` + `.prompt.md`.

**Foundation specimens** (`guidelines/`, shown on the Design System tab)
- Type · Colors · Spacing · Brand cards.

**UI kit** (`ui_kits/storefront/`)
- Interactive home → category → product modal → cart, composed from the components. English (`index.html`) + Hebrew RTL (`index-he.html`). See its `README.md`.

**Assets** (`assets/`)
- `logo/`, `icons/`, `imagery/` (hero), `categories/` (4 collection tiles), `products/` (sample photography).

---

## Using this in a non-React codebase (e.g. the live vanilla-JS site)

The live Tamar Kfir storefront is **vanilla JavaScript (MVC) + plain CSS**, not React. The React files under `components/` and `ui_kits/` are **prototyping recreations** — do **not** paste their JSX into the production site. Instead, lift the foundations:

1. **Tokens are the product.** Link `styles.css` (or copy `tokens/*.css`) and use the CSS custom properties directly: `color: var(--tk-text)`, `background: var(--tk-gold)`, `font-family: var(--tk-font-display)`, `box-shadow: var(--tk-shadow-card)`, etc. They drop into ordinary CSS with no build step.
2. **Rebuild components in the site's own idiom.** Read each component's `.jsx` + `.prompt.md` as a *spec* (structure, states, spacing, hover/press behaviour) and re-express it as the plain HTML/CSS the page already uses. Example — the primary button is: dark `var(--tk-ink)` background, white text, `radius 0`, uppercase, `letter-spacing: var(--tk-track-wide)`, darkens to `var(--tk-ink-deep)` on hover. That's a few CSS lines, not a React import.
3. **Follow the rules above** (Content Fundamentals, Visual Foundations, Iconography) for voice, casing, colour discipline, sharp corners, soft shadows, hover-lift.
4. **Reuse the real assets** in `assets/` (logo, icons, photography) as-is.
5. **RTL/Hebrew** works the same in plain CSS: the `[dir='rtl']` token remap in `tokens/typography.css` switches families to Rubik for any `dir="rtl"` subtree — no JS needed.

> **For Claude Code:** when editing the production site, treat this system as **tokens + guidelines + assets**, written in the page's existing HTML/CSS style. Match the visual language; don't introduce React.

> **Scope guardrail:** this design system is a *reference/spec*, not a description of how the live code is wired (the site does **not** currently use the `--tk-*` tokens). Use it for **brand values and new elements/components**. Do **not** refactor existing, working markup/CSS to "comply" (e.g. swapping hardcoded values for `--tk-*` tokens) unless the user explicitly asks for a consistency pass. When the DS and the live code disagree on a detail, the **live code wins** unless the user is deliberately converging on the DS. When adding to a page, match that page's existing conventions first.

---

## Caveats & substitutions

- **Fonts load from Google Fonts** (Montserrat, Cormorant Garamond, Rubik) — the same way the live site does; no local font binaries ship here. The DS compiler therefore reports *0 @font-face* (remote `@import`s aren't parsed as local faces). If you need offline/self-hosted fonts, add the `.woff2` files + `@font-face` rules and tell me.
- **Cormorant Garamond** is my editorial interpretation of the brand's intended serif accent for titles/headings (the repo's newer mock used Playfair Display; the live site is all Montserrat). Swap if you prefer the exact mock pairing.
- The live store is **bilingual (Hebrew RTL) + multi-currency**; the UI kit ships both an English/ILS surface (`index.html`) and a full Hebrew RTL mirror (`index-he.html`).
