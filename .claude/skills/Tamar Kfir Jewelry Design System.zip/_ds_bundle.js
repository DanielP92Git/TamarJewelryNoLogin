/* @ds-bundle: {"format":3,"namespace":"TamarKfirJewelryDesignSystem_332983","components":[{"name":"CategoryTile","sourcePath":"components/commerce/CategoryTile.jsx"},{"name":"ProductCard","sourcePath":"components/commerce/ProductCard.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"PriceTag","sourcePath":"components/core/PriceTag.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"QuantityStepper","sourcePath":"components/forms/QuantityStepper.jsx"},{"name":"Footer","sourcePath":"components/layout/Footer.jsx"},{"name":"NavBar","sourcePath":"components/layout/NavBar.jsx"}],"sourceHashes":{"components/commerce/CategoryTile.jsx":"aae9448d4a6a","components/commerce/ProductCard.jsx":"88f85bbb0069","components/core/Badge.jsx":"a108789bc8ba","components/core/Button.jsx":"7bb8551171f5","components/core/IconButton.jsx":"c42214d76ea2","components/core/PriceTag.jsx":"621bffae847d","components/forms/Input.jsx":"9acbcf00c5cb","components/forms/QuantityStepper.jsx":"f15fb2d4b94f","components/layout/Footer.jsx":"56b63c933950","components/layout/NavBar.jsx":"07b263394103","ui_kits/storefront/app-he.js":"decdd8d23d9b","ui_kits/storefront/app.js":"5b8b14668379","ui_kits/storefront/data-he.js":"64e277ce97a9","ui_kits/storefront/data.js":"c50ee3288129"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TamarKfirJewelryDesignSystem_332983 = window.TamarKfirJewelryDesignSystem_332983 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/commerce/CategoryTile.jsx
try { (() => {
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — CategoryTile
 * Full-bleed photo with a bottom protection scrim and a centered,
 * wide-tracked uppercase label. Letter-spacing opens slightly on
 * hover — the brand's signature category treatment.
 */
function CategoryTile({
  image,
  label,
  href = '#',
  height = 280,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      display: 'block',
      height,
      overflow: 'hidden',
      borderRadius: 'var(--tk-radius-sm)',
      textDecoration: 'none',
      transform: hover ? 'translateY(-4px)' : 'none',
      transition: 'transform var(--tk-dur) var(--tk-ease)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: label,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      transform: hover ? 'scale(1.05)' : 'scale(1)',
      transition: 'transform var(--tk-dur-slow) var(--tk-ease)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'center',
      padding: '2.5rem 1.5rem 1.5rem',
      background: 'var(--tk-scrim-bottom)',
      color: '#fff',
      fontFamily: 'var(--tk-font-display)',
      fontWeight: 'var(--tk-weight-light)',
      fontSize: 'clamp(0.9rem, 1.2vw, 1.1rem)',
      letterSpacing: hover ? '0.3em' : 'var(--tk-track-hero)',
      textTransform: 'uppercase',
      textShadow: '0 2px 12px rgba(0,0,0,0.5)',
      textAlign: 'center',
      transition: 'letter-spacing var(--tk-dur-slow) var(--tk-ease)'
    }
  }, label));
}
Object.assign(__ds_scope, { CategoryTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/CategoryTile.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tamar Kfir Jewelry — Badge
 * Small uppercase marker for product status: sale, sold-out, or a
 * soft "Handmade" tag. Sits over imagery (absolute) or inline.
 */
function Badge({
  children,
  variant = 'neutral',
  ...rest
}) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    fontFamily: 'var(--tk-font-body)',
    fontSize: 'var(--tk-size-caption)',
    fontWeight: 'var(--tk-weight-semibold)',
    letterSpacing: 'var(--tk-track-label)',
    textTransform: 'uppercase',
    padding: '0.35rem 0.7rem',
    lineHeight: 1,
    whiteSpace: 'nowrap'
  };
  const variants = {
    neutral: {
      background: 'var(--tk-ink)',
      color: '#fff'
    },
    gold: {
      background: 'var(--tk-gold)',
      color: 'var(--tk-ink)'
    },
    soft: {
      background: 'var(--tk-gold-tint)',
      color: 'var(--tk-gold-hover)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--tk-text-muted)',
      border: '1px solid var(--tk-border-strong)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...variants[variant]
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — Button
 * The brand's action element. Dark "ink" is the default storefront
 * button (square, uppercase). The gold-outline pill is the hero
 * call-to-action over photography. Gold-solid is a softer accent.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  onClick,
  type = 'button',
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const sizes = {
    sm: {
      padding: '0.6rem 1.4rem',
      fontSize: '0.7rem'
    },
    md: {
      padding: '0.85rem 2rem',
      fontSize: '0.78rem'
    },
    lg: {
      padding: '1.05rem 2.6rem',
      fontSize: '0.82rem'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.6rem',
    fontFamily: 'var(--tk-font-body)',
    fontWeight: 'var(--tk-weight-semibold)',
    letterSpacing: 'var(--tk-track-wide)',
    textTransform: 'uppercase',
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    border: '1px solid transparent',
    transition: 'all var(--tk-dur) var(--tk-ease)',
    width: fullWidth ? '100%' : 'auto',
    opacity: disabled ? 0.45 : 1,
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: hover && !disabled ? 'var(--tk-ink-deep)' : 'var(--tk-ink)',
      color: '#fff',
      borderRadius: 'var(--tk-radius-none)'
    },
    gold: {
      background: hover && !disabled ? 'var(--tk-gold-hover)' : 'var(--tk-gold)',
      color: 'var(--tk-ink)',
      borderRadius: 'var(--tk-radius-none)'
    },
    outline: {
      background: hover && !disabled ? '#fff' : 'rgba(255,255,255,0.96)',
      color: 'var(--tk-gold)',
      borderColor: 'var(--tk-gold)',
      borderRadius: 'var(--tk-radius-pill)',
      transform: hover && !disabled ? 'var(--tk-lift)' : 'none',
      boxShadow: hover && !disabled ? 'var(--tk-shadow-pill)' : 'none'
    },
    ghost: {
      background: 'transparent',
      color: hover && !disabled ? 'var(--tk-text)' : 'var(--tk-text-muted)',
      borderColor: 'transparent',
      borderRadius: 'var(--tk-radius-none)',
      textDecoration: 'underline',
      textUnderlineOffset: '4px',
      textDecorationColor: 'var(--tk-border-strong)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    onClick: disabled ? undefined : onClick,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...variants[variant]
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — IconButton
 * Square, borderless icon target for header utilities (cart, menu,
 * close) and social bubbles. Pass an <img>/SVG as children.
 */
function IconButton({
  children,
  label,
  variant = 'plain',
  size = 40,
  onClick,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: size,
    height: size,
    padding: 0,
    cursor: 'pointer',
    background: 'transparent',
    border: 'none',
    transition: 'all var(--tk-dur) var(--tk-ease)'
  };
  const variants = {
    plain: {
      opacity: hover ? 1 : 0.78
    },
    circle: {
      border: '1px solid rgba(168,139,99,0.25)',
      borderRadius: 'var(--tk-radius-round)',
      background: hover ? 'var(--tk-gold)' : '#fff',
      transform: hover ? 'var(--tk-lift)' : 'none',
      boxShadow: hover ? 'var(--tk-shadow-gold)' : 'none'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...variants[variant]
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: Math.round(size * 0.45),
      height: Math.round(size * 0.45),
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, children));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/PriceTag.jsx
try { (() => {
/**
 * Tamar Kfir Jewelry — PriceTag
 * Renders a price with optional struck-through original and discount.
 * Currency-aware (₪ / $) to match the bilingual ILS/USD storefront.
 */
function PriceTag({
  amount,
  original,
  currency = 'ILS',
  size = 'md',
  align = 'center'
}) {
  const symbol = currency === 'USD' ? '$' : '₪';
  const fmt = n => `${symbol}${n}`;
  const scale = {
    sm: {
      now: '1rem',
      was: '0.8rem'
    },
    md: {
      now: '1.2rem',
      was: '0.9rem'
    },
    lg: {
      now: '1.5rem',
      was: '1rem'
    }
  }[size];
  const onSale = original != null && original > amount;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center',
      gap: '0.6rem',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: scale.now,
      fontWeight: 'var(--tk-weight-semibold)',
      color: onSale ? 'var(--tk-gold-hover)' : 'var(--tk-text)',
      letterSpacing: 'var(--tk-track-tight)'
    }
  }, fmt(amount)), onSale && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: scale.was,
      color: 'var(--tk-text-faint)',
      textDecoration: 'line-through',
      opacity: 0.7
    }
  }, fmt(original)));
}
Object.assign(__ds_scope, { PriceTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/PriceTag.jsx", error: String((e && e.message) || e) }); }

// components/commerce/ProductCard.jsx
try { (() => {
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — ProductCard
 * The storefront grid tile: beige card, square photo, centered
 * title, price, and a full-width dark "Add to Cart" bar. Lifts on
 * hover. Optional sale badge over the image.
 */
function ProductCard({
  image,
  title,
  price,
  original,
  currency = 'ILS',
  badge,
  addLabel = 'Add to Cart',
  onAdd,
  onClick
}) {
  const [hover, setHover] = useState(false);
  const [btnHover, setBtnHover] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick,
    style: {
      width: '20rem',
      maxWidth: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--tk-surface-beige)',
      borderRadius: 'var(--tk-radius-sm)',
      overflow: 'hidden',
      cursor: 'pointer',
      boxShadow: hover ? 'var(--tk-shadow-card-hover)' : 'var(--tk-shadow-card)',
      transform: hover ? 'var(--tk-lift)' : 'none',
      transition: 'transform var(--tk-dur-fast) var(--tk-ease), box-shadow var(--tk-dur-fast) var(--tk-ease)',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '20rem',
      overflow: 'hidden',
      background: 'var(--tk-surface)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      transform: hover ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform var(--tk-dur-slow) var(--tk-ease)'
    }
  }), badge && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '0.85rem',
      left: '0.85rem'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: "gold"
  }, badge))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '1rem 0.75rem 0.5rem',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--tk-size-title)',
      fontWeight: 'var(--tk-weight-medium)',
      color: 'var(--tk-text)',
      lineHeight: 'var(--tk-leading-snug)'
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '0.25rem 0 0.85rem'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.PriceTag, {
    amount: price,
    original: original,
    currency: currency,
    size: "md",
    align: "center"
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onAdd && onAdd();
    },
    onMouseEnter: () => setBtnHover(true),
    onMouseLeave: () => setBtnHover(false),
    style: {
      width: '90%',
      margin: '0 auto 1rem',
      height: 40,
      border: 'none',
      background: btnHover ? 'var(--tk-ink-deep)' : 'var(--tk-ink)',
      color: '#fff',
      fontFamily: 'var(--tk-font-body)',
      fontSize: '0.78rem',
      fontWeight: 'var(--tk-weight-semibold)',
      letterSpacing: 'var(--tk-track-label)',
      textTransform: 'uppercase',
      cursor: 'pointer',
      transition: 'background var(--tk-dur) var(--tk-ease)'
    }
  }, addLabel));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — Input
 * Quiet text field for contact forms and newsletter sign-up.
 * Optional uppercase label; gold focus ring; sharp corners.
 */
function Input({
  label,
  type = 'text',
  placeholder,
  value,
  defaultValue,
  onChange,
  fullWidth = true,
  id,
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
      width: fullWidth ? '100%' : 'auto',
      fontFamily: 'var(--tk-font-body)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--tk-size-label)',
      fontWeight: 'var(--tk-weight-medium)',
      letterSpacing: 'var(--tk-track-label)',
      textTransform: 'uppercase',
      color: 'var(--tk-text-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      boxSizing: 'border-box',
      padding: '0.85rem 1rem',
      fontFamily: 'var(--tk-font-body)',
      fontSize: 'var(--tk-size-body)',
      color: 'var(--tk-text)',
      background: 'var(--tk-white)',
      border: `1px solid ${focus ? 'var(--tk-gold)' : 'var(--tk-border-strong)'}`,
      borderRadius: 'var(--tk-radius-xs)',
      outline: 'none',
      boxShadow: focus ? '0 0 0 3px rgba(197,165,114,0.12)' : 'none',
      transition: 'border-color var(--tk-dur) var(--tk-ease), box-shadow var(--tk-dur) var(--tk-ease)'
    }
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/QuantityStepper.jsx
try { (() => {
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — QuantityStepper
 * Bordered − [n] + control used in the cart. Sharp corners,
 * hairline border, hover-grey on the buttons.
 */
function QuantityStepper({
  value,
  defaultValue = 1,
  min = 1,
  max = 99,
  onChange,
  width = 110
}) {
  const controlled = value != null;
  const [internal, setInternal] = useState(defaultValue);
  const [hovered, setHovered] = useState(null); // 'dec' | 'inc' | null
  const qty = controlled ? value : internal;
  const set = next => {
    const clamped = Math.max(min, Math.min(max, next));
    if (!controlled) setInternal(clamped);
    onChange && onChange(clamped);
  };
  const btnStyle = (key, disabled) => ({
    width: 34,
    height: 38,
    border: 'none',
    background: hovered === key && !disabled ? 'var(--tk-surface)' : 'transparent',
    color: disabled ? 'var(--tk-text-faint)' : 'var(--tk-text-muted)',
    fontSize: '1rem',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'background var(--tk-dur-fast) var(--tk-ease)',
    fontFamily: 'var(--tk-font-body)'
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      width,
      border: '1px solid var(--tk-border-strong)',
      borderRadius: 'var(--tk-radius-none)',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: qty <= min,
    onClick: () => set(qty - 1),
    onMouseEnter: () => setHovered('dec'),
    onMouseLeave: () => setHovered(null),
    style: btnStyle('dec', qty <= min)
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontSize: 'var(--tk-size-small)',
      color: 'var(--tk-text)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, qty), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: qty >= max,
    onClick: () => set(qty + 1),
    onMouseEnter: () => setHovered('inc'),
    onMouseLeave: () => setHovered(null),
    style: btnStyle('inc', qty >= max)
  }, "+"));
}
Object.assign(__ds_scope, { QuantityStepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/QuantityStepper.jsx", error: String((e && e.message) || e) }); }

// components/layout/Footer.jsx
try { (() => {
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — Footer
 * Three-column link footer (Cartier-inspired) over white, capped by
 * a black copyright bar. Column headers are uppercase + wide-tracked.
 */
function Footer({
  columns = [{
    heading: 'Shop',
    links: ['Necklaces', 'Crochet Necklaces', 'Hoop Earrings', 'Dangle Earrings']
  }, {
    heading: 'Customer Care',
    links: ['Shipping & Cancellation', 'Contact Me']
  }, {
    heading: 'Info',
    links: ['Jewelry Workshop', 'About']
  }],
  copyright = '© 2024 Tamar Kfir Jewelry. All Rights Reserved.',
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      width: '100%',
      background: 'var(--tk-white)',
      borderTop: '1px solid var(--tk-border)',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '4rem',
      maxWidth: 760,
      margin: '0 auto',
      padding: '4rem 2rem 3.5rem'
    }
  }, columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.heading,
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--tk-size-label)',
      fontWeight: 'var(--tk-weight-semibold)',
      letterSpacing: 'var(--tk-track-label)',
      textTransform: 'uppercase',
      color: 'var(--tk-text)',
      marginBottom: '1rem'
    }
  }, col.heading), col.links.map(link => /*#__PURE__*/React.createElement(FooterLink, {
    key: link,
    label: link,
    onClick: () => onNavigate && onNavigate(link)
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--tk-black)',
      color: '#fff',
      textAlign: 'center',
      padding: '1.5rem 2rem',
      fontSize: 'var(--tk-size-caption)',
      letterSpacing: 'var(--tk-track-tight)'
    }
  }, copyright));
}
function FooterLink({
  label,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onClick && onClick();
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontSize: '0.8rem',
      letterSpacing: 'var(--tk-track-body)',
      textTransform: 'uppercase',
      textDecoration: 'none',
      color: hover ? 'var(--tk-text)' : 'var(--tk-text-muted)',
      lineHeight: 1.8,
      marginBottom: '0.6rem',
      transition: 'color var(--tk-dur) var(--tk-ease)'
    }
  }, label);
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Footer.jsx", error: String((e && e.message) || e) }); }

// components/layout/NavBar.jsx
try { (() => {
const {
  useState
} = React;
/**
 * Tamar Kfir Jewelry — NavBar
 * Fixed storefront header: TK logo, centered uppercase nav, and a
 * cart icon with count. `transparent` mode sits over the hero image
 * (white text); `solid` is the white sticky bar used on inner pages.
 */
function NavBar({
  logoSrc,
  links = ['Home', 'Shop', 'Jewelry Workshop', 'About', 'Contact Me'],
  active,
  cartCount = 0,
  mode = 'solid',
  currency = 'ILS',
  onCart,
  onNavigate
}) {
  const transparent = mode === 'transparent';
  const ink = transparent ? '#fff' : 'var(--tk-text-muted)';
  const inkActive = transparent ? '#fff' : 'var(--tk-text)';
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'relative',
      zIndex: 'var(--tk-z-header)',
      width: '100%',
      height: 'var(--tk-header-height)',
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 2.5rem',
      background: transparent ? 'transparent' : 'var(--tk-white)',
      borderBottom: transparent ? 'none' : '1px solid var(--tk-border-light)',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate('Home');
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      flex: '0 0 auto',
      textDecoration: 'none'
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Tamar Kfir Jewelry",
    style: {
      height: 52,
      width: 'auto',
      filter: transparent ? 'invert(1) brightness(2)' : 'none'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--tk-font-serif)',
      fontStyle: 'italic',
      fontSize: '1.8rem',
      color: inkActive
    }
  }, "Tamar Kfir")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: '2.2rem',
      alignItems: 'center'
    }
  }, links.map(l => /*#__PURE__*/React.createElement(NavLink, {
    key: l,
    label: l,
    active: l === active,
    color: ink,
    activeColor: inkActive,
    onClick: () => onNavigate && onNavigate(l)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.4rem',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--tk-size-label)',
      letterSpacing: 'var(--tk-track-body)',
      textTransform: 'uppercase',
      color: ink
    }
  }, currency), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onCart,
    "aria-label": "Cart",
    style: {
      position: 'relative',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 4,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(CartGlyph, {
    color: transparent ? '#fff' : 'var(--tk-text)'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -6,
      right: -8,
      minWidth: 18,
      height: 18,
      padding: '0 4px',
      boxSizing: 'border-box',
      borderRadius: 'var(--tk-radius-round)',
      background: transparent ? 'rgba(255,255,255,0.95)' : 'var(--tk-ink)',
      color: transparent ? 'var(--tk-ink)' : '#fff',
      fontSize: '0.62rem',
      fontWeight: 'var(--tk-weight-semibold)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, cartCount))));
}
function NavLink({
  label,
  active,
  color,
  activeColor,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onClick && onClick();
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontSize: 'var(--tk-size-label)',
      fontWeight: 'var(--tk-weight-medium)',
      letterSpacing: 'var(--tk-track-label)',
      textTransform: 'uppercase',
      textDecoration: 'none',
      color: active || hover ? activeColor : color,
      opacity: active || hover ? 1 : 0.85,
      transition: 'color var(--tk-dur) var(--tk-ease), opacity var(--tk-dur) var(--tk-ease)',
      whiteSpace: 'nowrap'
    }
  }, label);
}
function CartGlyph({
  color
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: "1.5"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/storefront/app-he.js
try { (() => {
/* Tamar Kfir Jewelry — Storefront UI kit (Hebrew / RTL)
   Mirror of app.js with Hebrew copy, dir="rtl", Rubik typography,
   and the cart drawer sliding from the left. */
let NavBar, Footer, CategoryTile, ProductCard, PriceTag, Badge, Button, QuantityStepper;
const {
  useState
} = React;
const LOGO = '../../assets/logo/tamar-logo.webp';
const HERO = '../../assets/imagery/hero-main.webp';
const NAV_LINKS = ['בית', 'חנות', 'סדנת תכשיטים', 'אודות', 'צרי קשר'];
const ADD = 'הוסיפי לסל';

/* ---------------- Home ---------------- */
function Home({
  onCategory,
  onProduct
}) {
  const featured = window.TK_DATA_HE.products.slice(0, 4);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      height: '78vh',
      minHeight: 540,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: HERO,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center 15%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, rgba(0,0,0,0.25), rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.35))'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    logoSrc: LOGO,
    links: NAV_LINKS,
    active: "\u05D1\u05D9\u05EA",
    mode: "transparent",
    cartCount: window.__cartCount || 0,
    onCart: window.__openCart,
    onNavigate: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: '14%',
      zIndex: 2,
      textAlign: 'center',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 1.6rem',
      fontWeight: 300,
      fontSize: 'clamp(2rem, 3.4vw, 3rem)',
      letterSpacing: '0.04em',
      textShadow: '0 3px 15px rgba(0,0,0,0.6)'
    }
  }, "\u05D0\u05D7\u05EA \u05D5\u05D9\u05D7\u05D9\u05D3\u05D4"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    onClick: () => document.getElementById('shop').scrollIntoView({
      behavior: 'smooth'
    })
  }, "\u05DC\u05D2\u05DC\u05D5\u05EA \u05D0\u05EA \u05D4\u05E7\u05D5\u05DC\u05E7\u05E6\u05D9\u05D4"))), /*#__PURE__*/React.createElement("section", {
    id: "shop",
    style: {
      maxWidth: 1100,
      margin: '0 auto',
      padding: '5rem 2rem 2rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "\u05E7\u05D5\u05DC\u05E7\u05E6\u05D9\u05D5\u05EA",
    title: "\u05E7\u05E0\u05D5 \u05DC\u05E4\u05D9 \u05E7\u05D8\u05D2\u05D5\u05E8\u05D9\u05D4"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      marginTop: '2.5rem'
    }
  }, window.TK_DATA_HE.categories.map(c => /*#__PURE__*/React.createElement(CategoryTile, {
    key: c.slug,
    image: c.image,
    label: c.name,
    height: 300,
    onClick: e => {
      e.preventDefault();
      onCategory(c.slug);
    }
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '4rem 2rem 5rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "\u05D7\u05D3\u05E9 \u05D5\u05D0\u05D4\u05D5\u05D1",
    title: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u05E0\u05D1\u05D7\u05E8\u05D9\u05DD"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: 28,
      marginTop: '2.5rem'
    }
  }, featured.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    image: p.image,
    title: p.name,
    price: p.price,
    original: p.original,
    badge: p.badge,
    addLabel: ADD,
    onAdd: () => window.__addToCart(p),
    onClick: () => onProduct(p)
  })))), /*#__PURE__*/React.createElement(Footer, {
    columns: HE_FOOTER,
    copyright: "\xA9 2024 \u05EA\u05DE\u05E8 \u05DB\u05E4\u05D9\u05E8 \u05EA\u05DB\u05E9\u05D9\u05D8\u05D9\u05DD. \u05DB\u05DC \u05D4\u05D6\u05DB\u05D5\u05D9\u05D5\u05EA \u05E9\u05DE\u05D5\u05E8\u05D5\u05EA.",
    onNavigate: () => {}
  }));
}
const HE_FOOTER = [{
  heading: 'חנות',
  links: ['שרשראות', 'שרשראות סרוגות', 'עגילי חישוק', 'עגילים תלויים']
}, {
  heading: 'שירות לקוחות',
  links: ['משלוח וביטול', 'צרי קשר']
}, {
  heading: 'אודות',
  links: ['סדנת תכשיטים', 'אודותי']
}];

/* ---------------- Category ---------------- */
function CategoryView({
  slug,
  onBack,
  onProduct
}) {
  const cat = window.TK_DATA_HE.categories.find(c => c.slug === slug);
  const items = window.TK_DATA_HE.products.filter(p => p.category === slug);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NavBar, {
    logoSrc: LOGO,
    links: NAV_LINKS,
    active: "\u05D7\u05E0\u05D5\u05EA",
    mode: "solid",
    cartCount: window.__cartCount || 0,
    onCart: window.__openCart,
    onNavigate: l => {
      if (l === 'בית') onBack();
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 280,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: cat.image,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center 35%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0.28)'
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: 0,
      color: '#fff',
      fontWeight: 400,
      fontSize: '2.2rem',
      letterSpacing: '0.08em',
      textShadow: '0 2px 14px rgba(0,0,0,0.5)'
    }
  }, cat.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '2.5rem 2rem 1rem'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--tk-text-muted)',
      fontSize: '0.8rem',
      letterSpacing: '0.04em'
    }
  }, "\u05D7\u05D6\u05E8\u05D4 \u05DC\u05D3\u05E3 \u05D4\u05D1\u05D9\u05EA \u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '1.5rem 2rem 5rem',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: 28
    }
  }, items.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    image: p.image,
    title: p.name,
    price: p.price,
    original: p.original,
    badge: p.badge,
    addLabel: ADD,
    onAdd: () => window.__addToCart(p),
    onClick: () => onProduct(p)
  }))), /*#__PURE__*/React.createElement(Footer, {
    columns: HE_FOOTER,
    copyright: "\xA9 2024 \u05EA\u05DE\u05E8 \u05DB\u05E4\u05D9\u05E8 \u05EA\u05DB\u05E9\u05D9\u05D8\u05D9\u05DD. \u05DB\u05DC \u05D4\u05D6\u05DB\u05D5\u05D9\u05D5\u05EA \u05E9\u05DE\u05D5\u05E8\u05D5\u05EA.",
    onNavigate: () => {}
  }));
}

/* ---------------- Product Modal ---------------- */
function ProductModal({
  product,
  onClose
}) {
  const [active, setActive] = useState(0);
  const [qty, setQty] = useState(1);
  if (!product) return null;
  const gallery = product.gallery || [product.image];
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'var(--tk-overlay)',
      zIndex: 1055,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: '#fff',
      width: '92%',
      maxWidth: 960,
      maxHeight: '92vh',
      display: 'flex',
      position: 'relative',
      boxShadow: 'var(--tk-shadow-modal)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "\u05E1\u05D2\u05D9\u05E8\u05D4",
    style: {
      position: 'absolute',
      top: 16,
      left: 18,
      zIndex: 5,
      background: 'none',
      border: 'none',
      fontSize: 28,
      lineHeight: 1,
      color: 'var(--tk-ink)',
      cursor: 'pointer'
    }
  }, "\xD7"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96,
      flex: 'none',
      padding: '20px 10px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      background: '#fff',
      overflowY: 'auto'
    }
  }, gallery.map((g, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActive(i),
    style: {
      width: 76,
      height: 76,
      padding: 0,
      border: i === active ? '1px solid var(--tk-gold)' : '1px solid var(--tk-border)',
      background: 'var(--tk-surface)',
      cursor: 'pointer',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: g,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1.4',
      background: 'var(--tk-surface)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: gallery[active],
    alt: product.name,
    style: {
      maxWidth: '100%',
      maxHeight: '92vh',
      objectFit: 'contain',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1',
      maxWidth: 340,
      padding: '46px 34px 28px',
      display: 'flex',
      flexDirection: 'column',
      overflowY: 'auto',
      textAlign: 'right'
    }
  }, product.badge && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: product.badge === 'מבצע' ? 'gold' : 'soft'
  }, product.badge)), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 6px',
      fontWeight: 500,
      fontSize: '1.7rem',
      color: 'var(--tk-ink)',
      lineHeight: 1.2
    }
  }, product.name), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(PriceTag, {
    amount: product.price,
    original: product.original,
    size: "lg",
    align: "right"
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 28px',
      fontSize: '0.98rem',
      lineHeight: 1.85,
      color: 'var(--tk-text-soft)'
    }
  }, product.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      borderTop: '1px solid var(--tk-border)',
      paddingTop: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.78rem',
      color: 'var(--tk-text-muted)'
    }
  }, "\u05DB\u05DE\u05D5\u05EA"), /*#__PURE__*/React.createElement(QuantityStepper, {
    value: qty,
    min: 1,
    max: 9,
    onChange: setQty
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => {
      window.__addToCart(product, qty);
      onClose();
    }
  }, ADD)))));
}

/* ---------------- Cart Drawer (slides from the LEFT for RTL) ---------------- */
function CartDrawer({
  open,
  items,
  onClose,
  onQty,
  onRemove
}) {
  const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 1056,
      pointerEvents: open ? 'auto' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0.45)',
      opacity: open ? 1 : 0,
      transition: 'opacity 0.3s ease'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      height: '100%',
      width: 420,
      maxWidth: '90vw',
      background: '#fff',
      boxShadow: '8px 0 30px rgba(0,0,0,0.12)',
      transform: open ? 'translateX(0)' : 'translateX(-100%)',
      transition: 'transform 0.35s var(--tk-ease)',
      display: 'flex',
      flexDirection: 'column',
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px',
      borderBottom: '1px solid var(--tk-border)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.95rem',
      fontWeight: 600,
      color: 'var(--tk-ink)'
    }
  }, "\u05E1\u05DC \u05E7\u05E0\u05D9\u05D5\u05EA"), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "\u05E1\u05D2\u05D9\u05E8\u05D4",
    style: {
      background: 'none',
      border: 'none',
      fontSize: 26,
      cursor: 'pointer',
      color: 'var(--tk-ink)'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '8px 28px'
    }
  }, items.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--tk-text-muted)',
      fontSize: '0.95rem',
      marginTop: 40,
      textAlign: 'center'
    }
  }, "\u05D4\u05E1\u05DC \u05E9\u05DC\u05DA \u05E8\u05D9\u05E7."), items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.id,
    style: {
      display: 'flex',
      gap: 16,
      padding: '20px 0',
      borderBottom: '1px solid var(--tk-border-light)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 80,
      height: 80,
      flex: 'none',
      background: 'var(--tk-surface)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: it.image,
    alt: it.name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1rem',
      color: 'var(--tk-text)',
      fontWeight: 500
    }
  }, it.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.92rem',
      fontWeight: 600,
      whiteSpace: 'nowrap'
    }
  }, "\u20AA", it.price * it.qty)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(QuantityStepper, {
    value: it.qty,
    min: 1,
    max: 9,
    width: 96,
    onChange: n => onQty(it.id, n)
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => onRemove(it.id),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '0.8rem',
      color: 'var(--tk-text-faint)',
      textDecoration: 'underline',
      textUnderlineOffset: 3
    }
  }, "\u05DC\u05D4\u05E1\u05D9\u05E8")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 28px 26px',
      borderTop: '1px solid var(--tk-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 6,
      fontSize: '0.95rem',
      color: 'var(--tk-text)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u05E1\u05DB\u05D5\u05DD \u05D1\u05D9\u05E0\u05D9\u05D9\u05DD"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "\u20AA", subtotal)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 18px',
      fontSize: '0.8rem',
      color: 'var(--tk-text-muted)'
    }
  }, "\u05D4\u05DE\u05E9\u05DC\u05D5\u05D7 \u05DE\u05D7\u05D5\u05E9\u05D1 \u05D1\u05EA\u05E9\u05DC\u05D5\u05DD."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    disabled: items.length === 0
  }, "\u05D4\u05DE\u05E9\u05DA \u05DC\u05EA\u05E9\u05DC\u05D5\u05DD"))));
}

/* ---------------- App shell ---------------- */
function App() {
  const [route, setRoute] = useState({
    name: 'home'
  });
  const [modal, setModal] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState([]);
  const addToCart = (p, qty = 1) => {
    setCart(prev => {
      const found = prev.find(x => x.id === p.id);
      if (found) return prev.map(x => x.id === p.id ? {
        ...x,
        qty: x.qty + qty
      } : x);
      return [...prev, {
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        qty
      }];
    });
    setCartOpen(true);
  };
  const cartCount = cart.reduce((s, it) => s + it.qty, 0);
  window.__addToCart = addToCart;
  window.__openCart = () => setCartOpen(true);
  window.__cartCount = cartCount;
  return /*#__PURE__*/React.createElement("div", {
    dir: "rtl"
  }, route.name === 'home' && /*#__PURE__*/React.createElement(Home, {
    onCategory: slug => {
      window.scrollTo(0, 0);
      setRoute({
        name: 'category',
        slug
      });
    },
    onProduct: setModal
  }), route.name === 'category' && /*#__PURE__*/React.createElement(CategoryView, {
    slug: route.slug,
    onBack: () => {
      window.scrollTo(0, 0);
      setRoute({
        name: 'home'
      });
    },
    onProduct: setModal
  }), /*#__PURE__*/React.createElement(ProductModal, {
    product: modal,
    onClose: () => setModal(null)
  }), /*#__PURE__*/React.createElement(CartDrawer, {
    open: cartOpen,
    items: cart,
    onClose: () => setCartOpen(false),
    onQty: (id, n) => setCart(prev => prev.map(x => x.id === id ? {
      ...x,
      qty: n
    } : x)),
    onRemove: id => setCart(prev => prev.filter(x => x.id !== id))
  }));
}
function SectionHead({
  eyebrow,
  title
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 10px',
      fontSize: '0.78rem',
      letterSpacing: '0.08em',
      color: 'var(--tk-gold-hover)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontWeight: 600,
      fontSize: '2rem',
      color: 'var(--tk-ink)'
    }
  }, title));
}
function tkBoot() {
  if (window.__tkBooted) return;
  const DS = window.TamarKfirJewelryDesignSystem_332983;
  if (!DS || !DS.Button) {
    setTimeout(tkBoot, 20);
    return;
  }
  ({
    NavBar,
    Footer,
    CategoryTile,
    ProductCard,
    PriceTag,
    Badge,
    Button,
    QuantityStepper
  } = DS);
  window.__tkBooted = true;
  window.__tkRoot = ReactDOM.createRoot(document.getElementById('app'));
  window.__tkRoot.render(/*#__PURE__*/React.createElement(App, null));
}
tkBoot();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/app-he.js", error: String((e && e.message) || e) }); }

// ui_kits/storefront/app.js
try { (() => {
/* Tamar Kfir Jewelry — Storefront UI kit
   Interactive click-through: home → category → product modal → cart.
   Composes the design-system components from the compiled bundle. */
let NavBar, Footer, CategoryTile, ProductCard, PriceTag, Badge, Button, QuantityStepper;
const {
  useState
} = React;
const LOGO = '../../assets/logo/tamar-logo.webp';
const HERO = '../../assets/imagery/hero-main.webp';
const NAV_LINKS = ['Home', 'Shop', 'Jewelry Workshop', 'About', 'Contact Me'];

/* ---------------- Home ---------------- */
function Home({
  onCategory,
  onProduct
}) {
  const featured = window.TK_DATA.products.slice(0, 4);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      height: '78vh',
      minHeight: 540,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: HERO,
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center 15%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to bottom, rgba(0,0,0,0.25), rgba(0,0,0,0.05) 40%, rgba(0,0,0,0.35))'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    logoSrc: LOGO,
    links: NAV_LINKS,
    active: "Home",
    mode: "transparent",
    cartCount: window.__cartCount || 0,
    onCart: window.__openCart,
    onNavigate: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: '14%',
      zIndex: 2,
      textAlign: 'center',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 1.6rem',
      fontFamily: 'var(--tk-font-display)',
      fontWeight: 300,
      fontSize: 'clamp(1.8rem, 3vw, 2.8rem)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      textShadow: '0 3px 15px rgba(0,0,0,0.6)'
    }
  }, "One of a kind in mind"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    onClick: () => document.getElementById('shop').scrollIntoView({
      behavior: 'smooth'
    })
  }, "Discover the Collection"))), /*#__PURE__*/React.createElement("section", {
    id: "shop",
    style: {
      maxWidth: 1100,
      margin: '0 auto',
      padding: '5rem 2rem 2rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Collections",
    title: "Shop by Category"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      marginTop: '2.5rem'
    }
  }, window.TK_DATA.categories.map(c => /*#__PURE__*/React.createElement(CategoryTile, {
    key: c.slug,
    image: c.image,
    label: c.name,
    height: 300,
    onClick: e => {
      e.preventDefault();
      onCategory(c.slug);
    }
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '4rem 2rem 5rem'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "New & Loved",
    title: "Featured Pieces"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: 28,
      marginTop: '2.5rem'
    }
  }, featured.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    image: p.image,
    title: p.name,
    price: p.price,
    original: p.original,
    badge: p.badge,
    onAdd: () => window.__addToCart(p),
    onClick: () => onProduct(p)
  })))), /*#__PURE__*/React.createElement(Footer, {
    onNavigate: () => {}
  }));
}

/* ---------------- Category ---------------- */
function CategoryView({
  slug,
  onBack,
  onProduct
}) {
  const cat = window.TK_DATA.categories.find(c => c.slug === slug);
  const items = window.TK_DATA.products.filter(p => p.category === slug);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NavBar, {
    logoSrc: LOGO,
    links: NAV_LINKS,
    active: "Shop",
    mode: "solid",
    cartCount: window.__cartCount || 0,
    onCart: window.__openCart,
    onNavigate: l => {
      if (l === 'Home') onBack();
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 280,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: cat.image,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition: 'center 35%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0.28)'
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: 0,
      color: '#fff',
      fontFamily: 'var(--tk-font-display)',
      fontWeight: 300,
      fontSize: '2.2rem',
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      textShadow: '0 2px 14px rgba(0,0,0,0.5)'
    }
  }, cat.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '2.5rem 2rem 1rem'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--tk-text-muted)',
      fontFamily: 'var(--tk-font-body)',
      fontSize: '0.75rem',
      letterSpacing: '0.12em',
      textTransform: 'uppercase'
    }
  }, "\u2190 Back to Home")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: '0 auto',
      padding: '1.5rem 2rem 5rem',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: 28
    }
  }, items.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    image: p.image,
    title: p.name,
    price: p.price,
    original: p.original,
    badge: p.badge,
    onAdd: () => window.__addToCart(p),
    onClick: () => onProduct(p)
  }))), /*#__PURE__*/React.createElement(Footer, {
    onNavigate: () => {}
  }));
}

/* ---------------- Product Modal ---------------- */
function ProductModal({
  product,
  onClose
}) {
  const [active, setActive] = useState(0);
  const [qty, setQty] = useState(1);
  if (!product) return null;
  const gallery = product.gallery || [product.image];
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'var(--tk-overlay)',
      zIndex: 1055,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: '#fff',
      width: '92%',
      maxWidth: 960,
      maxHeight: '92vh',
      display: 'flex',
      position: 'relative',
      boxShadow: 'var(--tk-shadow-modal)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      position: 'absolute',
      top: 16,
      right: 18,
      zIndex: 5,
      background: 'none',
      border: 'none',
      fontSize: 28,
      lineHeight: 1,
      color: 'var(--tk-ink)',
      cursor: 'pointer'
    }
  }, "\xD7"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96,
      flex: 'none',
      padding: '20px 10px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      background: '#fff',
      overflowY: 'auto'
    }
  }, gallery.map((g, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setActive(i),
    style: {
      width: 76,
      height: 76,
      padding: 0,
      border: i === active ? '1px solid var(--tk-gold)' : '1px solid var(--tk-border)',
      background: 'var(--tk-surface)',
      cursor: 'pointer',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: g,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1.4',
      background: 'var(--tk-surface)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: gallery[active],
    alt: product.name,
    style: {
      maxWidth: '100%',
      maxHeight: '92vh',
      objectFit: 'contain',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1',
      maxWidth: 340,
      padding: '46px 34px 28px',
      display: 'flex',
      flexDirection: 'column',
      overflowY: 'auto',
      fontFamily: 'var(--tk-font-body)'
    }
  }, product.badge && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: product.badge === 'Sale' ? 'gold' : 'soft'
  }, product.badge)), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 6px',
      fontFamily: 'var(--tk-font-serif)',
      fontWeight: 500,
      fontSize: '1.9rem',
      color: 'var(--tk-ink)',
      lineHeight: 1.2
    }
  }, product.name), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(PriceTag, {
    amount: product.price,
    original: product.original,
    size: "lg",
    align: "left"
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 28px',
      fontSize: '0.95rem',
      lineHeight: 1.75,
      color: 'var(--tk-text-soft)'
    }
  }, product.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      borderTop: '1px solid var(--tk-border)',
      paddingTop: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.7rem',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--tk-text-muted)'
    }
  }, "Qty"), /*#__PURE__*/React.createElement(QuantityStepper, {
    value: qty,
    min: 1,
    max: 9,
    onChange: setQty
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => {
      window.__addToCart(product, qty);
      onClose();
    }
  }, "Add to Cart")))));
}

/* ---------------- Cart Drawer ---------------- */
function CartDrawer({
  open,
  items,
  onClose,
  onQty,
  onRemove
}) {
  const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 1056,
      pointerEvents: open ? 'auto' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0.45)',
      opacity: open ? 1 : 0,
      transition: 'opacity 0.3s ease'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      height: '100%',
      width: 420,
      maxWidth: '90vw',
      background: '#fff',
      boxShadow: '-8px 0 30px rgba(0,0,0,0.12)',
      transform: open ? 'translateX(0)' : 'translateX(100%)',
      transition: 'transform 0.35s var(--tk-ease)',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'var(--tk-font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px',
      borderBottom: '1px solid var(--tk-border)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.8rem',
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      fontWeight: 600,
      color: 'var(--tk-ink)'
    }
  }, "Shopping Cart"), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      background: 'none',
      border: 'none',
      fontSize: 26,
      cursor: 'pointer',
      color: 'var(--tk-ink)'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '8px 28px'
    }
  }, items.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--tk-text-muted)',
      fontSize: '0.9rem',
      marginTop: 40,
      textAlign: 'center'
    }
  }, "Your cart is empty."), items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it.id,
    style: {
      display: 'flex',
      gap: 16,
      padding: '20px 0',
      borderBottom: '1px solid var(--tk-border-light)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 80,
      height: 80,
      flex: 'none',
      background: 'var(--tk-surface)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: it.image,
    alt: it.name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.95rem',
      color: 'var(--tk-text)',
      fontFamily: 'var(--tk-font-serif)',
      fontWeight: 500
    }
  }, it.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.9rem',
      fontWeight: 600,
      whiteSpace: 'nowrap'
    }
  }, "\u20AA", it.price * it.qty)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(QuantityStepper, {
    value: it.qty,
    min: 1,
    max: 9,
    width: 96,
    onChange: n => onQty(it.id, n)
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => onRemove(it.id),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontSize: '0.72rem',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--tk-text-faint)',
      textDecoration: 'underline',
      textUnderlineOffset: 3
    }
  }, "Remove")))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 28px 26px',
      borderTop: '1px solid var(--tk-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 6,
      fontSize: '0.9rem',
      color: 'var(--tk-text)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Subtotal"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, "\u20AA", subtotal)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 18px',
      fontSize: '0.74rem',
      color: 'var(--tk-text-muted)'
    }
  }, "Shipping calculated at checkout."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    disabled: items.length === 0
  }, "Proceed to Checkout"))));
}

/* ---------------- App shell ---------------- */
function App() {
  const [route, setRoute] = useState({
    name: 'home'
  });
  const [modal, setModal] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState([]);
  const addToCart = (p, qty = 1) => {
    setCart(prev => {
      const found = prev.find(x => x.id === p.id);
      if (found) return prev.map(x => x.id === p.id ? {
        ...x,
        qty: x.qty + qty
      } : x);
      return [...prev, {
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        qty
      }];
    });
    setCartOpen(true);
  };
  const cartCount = cart.reduce((s, it) => s + it.qty, 0);

  // expose helpers used by NavBar instances inside screens
  window.__addToCart = addToCart;
  window.__openCart = () => setCartOpen(true);
  window.__cartCount = cartCount;
  return /*#__PURE__*/React.createElement("div", null, route.name === 'home' && /*#__PURE__*/React.createElement(Home, {
    onCategory: slug => {
      window.scrollTo(0, 0);
      setRoute({
        name: 'category',
        slug
      });
    },
    onProduct: setModal
  }), route.name === 'category' && /*#__PURE__*/React.createElement(CategoryView, {
    slug: route.slug,
    onBack: () => {
      window.scrollTo(0, 0);
      setRoute({
        name: 'home'
      });
    },
    onProduct: setModal
  }), /*#__PURE__*/React.createElement(ProductModal, {
    product: modal,
    onClose: () => setModal(null)
  }), /*#__PURE__*/React.createElement(CartDrawer, {
    open: cartOpen,
    items: cart,
    onClose: () => setCartOpen(false),
    onQty: (id, n) => setCart(prev => prev.map(x => x.id === id ? {
      ...x,
      qty: n
    } : x)),
    onRemove: id => setCart(prev => prev.filter(x => x.id !== id))
  }));
}
function SectionHead({
  eyebrow,
  title
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 10px',
      fontSize: '0.68rem',
      letterSpacing: '0.22em',
      textTransform: 'uppercase',
      color: 'var(--tk-gold-hover)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--tk-font-serif)',
      fontWeight: 500,
      fontSize: '2.1rem',
      color: 'var(--tk-ink)',
      letterSpacing: '0.02em'
    }
  }, title));
}
function tkBoot() {
  if (window.__tkBooted) return;
  const DS = window.TamarKfirJewelryDesignSystem_332983;
  if (!DS || !DS.Button) {
    setTimeout(tkBoot, 20);
    return;
  }
  ({
    NavBar,
    Footer,
    CategoryTile,
    ProductCard,
    PriceTag,
    Badge,
    Button,
    QuantityStepper
  } = DS);
  window.__tkBooted = true;
  window.__tkRoot = ReactDOM.createRoot(document.getElementById('app'));
  window.__tkRoot.render(/*#__PURE__*/React.createElement(App, null));
}
tkBoot();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/app.js", error: String((e && e.message) || e) }); }

// ui_kits/storefront/data-he.js
try { (() => {
// Tamar Kfir Jewelry — Hebrew (RTL) storefront catalogue (demo data)
window.TK_DATA_HE = {
  categories: [{
    slug: 'crochet',
    name: 'שרשראות סרוגות',
    image: '../../assets/categories/crochet.webp'
  }, {
    slug: 'hoops',
    name: 'עגילי חישוק',
    image: '../../assets/categories/hoops.webp'
  }, {
    slug: 'dangle',
    name: 'עגילים תלויים',
    image: '../../assets/categories/dangle.webp'
  }, {
    slug: 'necklaces',
    name: 'שרשראות',
    image: '../../assets/categories/necklaces.webp'
  }],
  products: [{
    id: 'p1',
    category: 'crochet',
    name: 'צבעים אמיתיים',
    price: 450,
    image: '../../assets/products/crochet-01.jpg',
    badge: 'בעבודת יד',
    gallery: ['../../assets/products/crochet-01.jpg', '../../assets/products/crochet-02.jpg'],
    desc: 'שרשרת רבת־גדילים סרוגה בחוט מתכתי ובשלל חרוזי זכוכית — כחול, אדום וזהב — כך שאין שתי חתיכות זהות.'
  }, {
    id: 'p2',
    category: 'crochet',
    name: 'ירח כחול',
    price: 120,
    image: '../../assets/products/crochet-02.jpg',
    gallery: ['../../assets/products/crochet-02.jpg', '../../assets/products/crochet-01.jpg'],
    desc: 'חרוזי אינדיגו וטורקיז סרוגים על גדיל מתכתי דק. קלילה, שכבתית וזוהרת בשקט על העור.'
  }, {
    id: 'p3',
    category: 'necklaces',
    name: 'אבן הוולייט',
    price: 120,
    image: '../../assets/products/necklace-01.jpg',
    gallery: ['../../assets/products/necklace-01.jpg', '../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
    desc: 'תליון הוולייט בודד על שרשרת עדינה — אבן רגועה ולבנה לעטייה יומיומית.'
  }, {
    id: 'p4',
    category: 'necklaces',
    name: 'שדרה ירוקה',
    price: 150,
    original: 180,
    image: '../../assets/products/necklace-02.jpg',
    badge: 'מבצע',
    gallery: ['../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
    desc: 'גדילי אבן ירוקה שכבתיים שתופסים את אור אחר הצהריים. סוגר מתכוונן.'
  }, {
    id: 'p5',
    category: 'necklaces',
    name: "לחישת ג'ייד",
    price: 165,
    image: '../../assets/products/necklace-jade.jpg',
    gallery: ['../../assets/products/necklace-jade.jpg', '../../assets/products/necklace-01.jpg'],
    desc: "חרוזי ג'ייד חלקים משורשרים ביד, עם נגיעת זהב קטנה."
  }, {
    id: 'p6',
    category: 'hoops',
    name: 'חישוק קריסטל',
    price: 96,
    original: 120,
    image: '../../assets/products/hoop-02.jpg',
    badge: 'מבצע',
    gallery: ['../../assets/products/hoop-02.jpg', '../../assets/products/hoop-01.jpg'],
    desc: 'חישוקים דקים מצופי זהב עם טיפות קריסטל סגול ותכלת. קלילים להפליא.'
  }, {
    id: 'p7',
    category: 'hoops',
    name: 'חישוק בוקר',
    price: 90,
    image: '../../assets/products/hoop-01.jpg',
    gallery: ['../../assets/products/hoop-01.jpg', '../../assets/products/hoop-03.jpg'],
    desc: 'חישוקים יומיומיים עם פיזור חרוזים בגוונים חמים. נועדו להשתלב עם המועדפים שלך.'
  }, {
    id: 'p8',
    category: 'hoops',
    name: 'חישוק גן',
    price: 110,
    image: '../../assets/products/hoop-03.jpg',
    gallery: ['../../assets/products/hoop-03.jpg', '../../assets/products/hoop-04.jpg'],
    desc: 'חישוק מלא יותר עטוף בחרוזי זכוכית מעורבים — קצת צבע לבקרים אפורים.'
  }, {
    id: 'p9',
    category: 'dangle',
    name: 'טיפה מתוקה',
    price: 90,
    image: '../../assets/products/earring-01.jpg',
    gallery: ['../../assets/products/earring-01.jpg', '../../assets/products/earring-02.jpg'],
    desc: 'טיפות חרוזים קטנות שמתנדנדות איתך. עגיל שתשכחי שאת עונדת.'
  }, {
    id: 'p10',
    category: 'dangle',
    name: 'עגיל ALE',
    price: 240,
    image: '../../assets/products/earring-02.jpg',
    badge: 'בעבודת יד',
    gallery: ['../../assets/products/earring-02.jpg', '../../assets/products/earring-01.jpg'],
    desc: 'עגילים תלויים בולטים מאבן מלוטשת וחוט מתכתי — נועדו להיראות.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/data-he.js", error: String((e && e.message) || e) }); }

// ui_kits/storefront/data.js
try { (() => {
// Tamar Kfir Jewelry — sample storefront catalogue (demo data)
// Photography is the brand's own; copy mirrors the real product voice.
window.TK_DATA = {
  categories: [{
    slug: 'crochet',
    name: 'Crochet Necklaces',
    image: '../../assets/categories/crochet.webp'
  }, {
    slug: 'hoops',
    name: 'Hoop Earrings',
    image: '../../assets/categories/hoops.webp'
  }, {
    slug: 'dangle',
    name: 'Dangle Earrings',
    image: '../../assets/categories/dangle.webp'
  }, {
    slug: 'necklaces',
    name: 'Necklaces',
    image: '../../assets/categories/necklaces.webp'
  }],
  products: [{
    id: 'p1',
    category: 'crochet',
    name: 'True Colors',
    price: 450,
    image: '../../assets/products/crochet-01.jpg',
    badge: 'Handmade',
    gallery: ['../../assets/products/crochet-01.jpg', '../../assets/products/crochet-02.jpg'],
    desc: 'A multi-strand necklace crocheted with metallic thread and a riot of glass beads — blues, reds and golds woven together so no two sit the same way twice.'
  }, {
    id: 'p2',
    category: 'crochet',
    name: 'Blue Moon',
    price: 120,
    image: '../../assets/products/crochet-02.jpg',
    gallery: ['../../assets/products/crochet-02.jpg', '../../assets/products/crochet-01.jpg'],
    desc: 'Soft indigo and teal beads crocheted onto a fine metallic strand. Light, layered, and quietly luminous against the skin.'
  }, {
    id: 'p3',
    category: 'necklaces',
    name: 'Howlite Stone',
    price: 120,
    image: '../../assets/products/necklace-01.jpg',
    gallery: ['../../assets/products/necklace-01.jpg', '../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
    desc: 'A single howlite pendant on a delicate chain — calm, white-veined stone for everyday wear.'
  }, {
    id: 'p4',
    category: 'necklaces',
    name: 'Green Boulevard',
    price: 150,
    original: 180,
    image: '../../assets/products/necklace-02.jpg',
    badge: 'Sale',
    gallery: ['../../assets/products/necklace-02.jpg', '../../assets/products/necklace-03.jpg'],
    desc: 'Layered green-stone strands that catch the late afternoon light. Adjustable clasp.'
  }, {
    id: 'p5',
    category: 'necklaces',
    name: 'Jade Whisper',
    price: 165,
    image: '../../assets/products/necklace-jade.jpg',
    gallery: ['../../assets/products/necklace-jade.jpg', '../../assets/products/necklace-01.jpg'],
    desc: 'Smooth jade beads strung by hand, finished with a small gold-fill accent.'
  }, {
    id: 'p6',
    category: 'hoops',
    name: 'Crystal Hoop',
    price: 96,
    original: 120,
    image: '../../assets/products/hoop-02.jpg',
    badge: 'Sale',
    gallery: ['../../assets/products/hoop-02.jpg', '../../assets/products/hoop-01.jpg'],
    desc: 'Slim gold-fill hoops threaded with amethyst and aqua crystal drops. Feather-light to wear.'
  }, {
    id: 'p7',
    category: 'hoops',
    name: 'Morning Hoop',
    price: 90,
    image: '../../assets/products/hoop-01.jpg',
    gallery: ['../../assets/products/hoop-01.jpg', '../../assets/products/hoop-03.jpg'],
    desc: 'Everyday hoops with a scatter of warm-toned beads. Made to layer with your other favourites.'
  }, {
    id: 'p8',
    category: 'hoops',
    name: 'Garden Hoop',
    price: 110,
    image: '../../assets/products/hoop-03.jpg',
    gallery: ['../../assets/products/hoop-03.jpg', '../../assets/products/hoop-04.jpg'],
    desc: 'A fuller hoop wrapped in mixed glass beads — a little colour for grey mornings.'
  }, {
    id: 'p9',
    category: 'dangle',
    name: 'Sweet Drop',
    price: 90,
    image: '../../assets/products/earring-01.jpg',
    gallery: ['../../assets/products/earring-01.jpg', '../../assets/products/earring-02.jpg'],
    desc: 'Petite beaded drops that sway with you. The kind of earring you forget you are wearing.'
  }, {
    id: 'p10',
    category: 'dangle',
    name: 'ALE Dangle',
    price: 240,
    image: '../../assets/products/earring-02.jpg',
    badge: 'Handmade',
    gallery: ['../../assets/products/earring-02.jpg', '../../assets/products/earring-01.jpg'],
    desc: 'Statement dangles in faceted stone and metallic thread — designed to be noticed.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/storefront/data.js", error: String((e && e.message) || e) }); }

__ds_ns.CategoryTile = __ds_scope.CategoryTile;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.PriceTag = __ds_scope.PriceTag;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.QuantityStepper = __ds_scope.QuantityStepper;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
