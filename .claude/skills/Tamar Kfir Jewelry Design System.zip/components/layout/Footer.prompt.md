**Footer** — three-column link footer (Shop / Customer Care / Info) over white, capped by a black copyright bar. Column headers are uppercase and wide-tracked; links are uppercase grey that darken on hover.

```jsx
<Footer onNavigate={(label) => go(label)} />
```

Pass `columns` to customize headings/links and `copyright` for the bottom bar.
