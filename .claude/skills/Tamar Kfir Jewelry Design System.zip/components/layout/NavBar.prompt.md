**NavBar** — the fixed storefront header: TK logo, centered uppercase nav, currency, and a cart icon with count. Use `mode="transparent"` over the home hero (white text, the logo is inverted to white) and `mode="solid"` (white bar) on inner pages.

```jsx
<NavBar
  logoSrc="assets/logo/tamar-logo.webp"
  active="Shop"
  cartCount={2}
  mode="solid"
  onCart={openCart}
  onNavigate={(label) => go(label)}
/>
```
