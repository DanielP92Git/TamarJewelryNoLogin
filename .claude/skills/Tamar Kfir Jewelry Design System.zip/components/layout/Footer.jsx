import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — Footer
 * Three-column link footer (Cartier-inspired) over white, capped by
 * a black copyright bar. Column headers are uppercase + wide-tracked.
 */
export function Footer({
  columns = [
    { heading: 'Shop', links: ['Necklaces', 'Crochet Necklaces', 'Hoop Earrings', 'Dangle Earrings'] },
    { heading: 'Customer Care', links: ['Shipping & Cancellation', 'Contact Me'] },
    { heading: 'Info', links: ['Jewelry Workshop', 'About'] },
  ],
  copyright = '© 2024 Tamar Kfir Jewelry. All Rights Reserved.',
  onNavigate,
}) {
  return (
    <footer style={{ width: '100%', background: 'var(--tk-white)', borderTop: '1px solid var(--tk-border)', fontFamily: 'var(--tk-font-body)' }}>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '4rem',
          maxWidth: 760,
          margin: '0 auto',
          padding: '4rem 2rem 3.5rem',
        }}
      >
        {columns.map((col) => (
          <div key={col.heading} style={{ display: 'flex', flexDirection: 'column' }}>
            <span
              style={{
                fontSize: 'var(--tk-size-label)',
                fontWeight: 'var(--tk-weight-semibold)',
                letterSpacing: 'var(--tk-track-label)',
                textTransform: 'uppercase',
                color: 'var(--tk-text)',
                marginBottom: '1rem',
              }}
            >
              {col.heading}
            </span>
            {col.links.map((link) => (
              <FooterLink key={link} label={link} onClick={() => onNavigate && onNavigate(link)} />
            ))}
          </div>
        ))}
      </div>
      <div
        style={{
          background: 'var(--tk-black)',
          color: '#fff',
          textAlign: 'center',
          padding: '1.5rem 2rem',
          fontSize: 'var(--tk-size-caption)',
          letterSpacing: 'var(--tk-track-tight)',
        }}
      >
        {copyright}
      </div>
    </footer>
  );
}

function FooterLink({ label, onClick }) {
  const [hover, setHover] = useState(false);
  return (
    <a
      href="#"
      onClick={(e) => { e.preventDefault(); onClick && onClick(); }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        fontSize: '0.8rem',
        letterSpacing: 'var(--tk-track-body)',
        textTransform: 'uppercase',
        textDecoration: 'none',
        color: hover ? 'var(--tk-text)' : 'var(--tk-text-muted)',
        lineHeight: 1.8,
        marginBottom: '0.6rem',
        transition: 'color var(--tk-dur) var(--tk-ease)',
      }}
    >
      {label}
    </a>
  );
}
