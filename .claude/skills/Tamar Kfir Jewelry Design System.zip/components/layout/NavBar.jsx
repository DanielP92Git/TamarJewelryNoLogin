import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — NavBar
 * Fixed storefront header: TK logo, centered uppercase nav, and a
 * cart icon with count. `transparent` mode sits over the hero image
 * (white text); `solid` is the white sticky bar used on inner pages.
 */
export function NavBar({
  logoSrc,
  links = ['Home', 'Shop', 'Jewelry Workshop', 'About', 'Contact Me'],
  active,
  cartCount = 0,
  mode = 'solid',
  currency = 'ILS',
  onCart,
  onNavigate,
}) {
  const transparent = mode === 'transparent';
  const ink = transparent ? '#fff' : 'var(--tk-text-muted)';
  const inkActive = transparent ? '#fff' : 'var(--tk-text)';

  return (
    <header
      style={{
        position: 'relative',
        zIndex: 'var(--tk-z-header)',
        width: '100%',
        height: 'var(--tk-header-height)',
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 2.5rem',
        background: transparent ? 'transparent' : 'var(--tk-white)',
        borderBottom: transparent ? 'none' : '1px solid var(--tk-border-light)',
        fontFamily: 'var(--tk-font-body)',
      }}
    >
      {/* Brand */}
      <a
        href="#"
        onClick={(e) => { e.preventDefault(); onNavigate && onNavigate('Home'); }}
        style={{ display: 'flex', alignItems: 'center', flex: '0 0 auto', textDecoration: 'none' }}
      >
        {logoSrc ? (
          <img
            src={logoSrc}
            alt="Tamar Kfir Jewelry"
            style={{ height: 52, width: 'auto', filter: transparent ? 'invert(1) brightness(2)' : 'none' }}
          />
        ) : (
          <span style={{ fontFamily: 'var(--tk-font-serif)', fontStyle: 'italic', fontSize: '1.8rem', color: inkActive }}>
            Tamar Kfir
          </span>
        )}
      </a>

      {/* Nav */}
      <nav style={{ display: 'flex', gap: '2.2rem', alignItems: 'center' }}>
        {links.map((l) => (
          <NavLink
            key={l}
            label={l}
            active={l === active}
            color={ink}
            activeColor={inkActive}
            onClick={() => onNavigate && onNavigate(l)}
          />
        ))}
      </nav>

      {/* Utilities */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1.4rem', flex: '0 0 auto' }}>
        <span
          style={{
            fontSize: 'var(--tk-size-label)',
            letterSpacing: 'var(--tk-track-body)',
            textTransform: 'uppercase',
            color: ink,
          }}
        >
          {currency}
        </span>
        <button
          type="button"
          onClick={onCart}
          aria-label="Cart"
          style={{ position: 'relative', background: 'none', border: 'none', cursor: 'pointer', padding: 4, display: 'flex' }}
        >
          <CartGlyph color={transparent ? '#fff' : 'var(--tk-text)'} />
          <span
            style={{
              position: 'absolute',
              top: -6,
              right: -8,
              minWidth: 18,
              height: 18,
              padding: '0 4px',
              boxSizing: 'border-box',
              borderRadius: 'var(--tk-radius-round)',
              background: transparent ? 'rgba(255,255,255,0.95)' : 'var(--tk-ink)',
              color: transparent ? 'var(--tk-ink)' : '#fff',
              fontSize: '0.62rem',
              fontWeight: 'var(--tk-weight-semibold)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {cartCount}
          </span>
        </button>
      </div>
    </header>
  );
}

function NavLink({ label, active, color, activeColor, onClick }) {
  const [hover, setHover] = useState(false);
  return (
    <a
      href="#"
      onClick={(e) => { e.preventDefault(); onClick && onClick(); }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        fontSize: 'var(--tk-size-label)',
        fontWeight: 'var(--tk-weight-medium)',
        letterSpacing: 'var(--tk-track-label)',
        textTransform: 'uppercase',
        textDecoration: 'none',
        color: active || hover ? activeColor : color,
        opacity: active || hover ? 1 : 0.85,
        transition: 'color var(--tk-dur) var(--tk-ease), opacity var(--tk-dur) var(--tk-ease)',
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </a>
  );
}

function CartGlyph({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5">
      <path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
