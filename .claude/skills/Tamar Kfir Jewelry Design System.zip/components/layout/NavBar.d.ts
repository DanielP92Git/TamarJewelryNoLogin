import React from 'react';

export interface NavBarProps {
  /** Logo image URL (TK monogram). Falls back to a serif wordmark if omitted. */
  logoSrc?: string;
  /** Top-level nav labels */
  links?: string[];
  /** Currently active label */
  active?: string;
  cartCount?: number;
  /** transparent = white text over the hero; solid = white sticky bar */
  mode?: 'transparent' | 'solid';
  currency?: 'ILS' | 'USD';
  onCart?: () => void;
  onNavigate?: (label: string) => void;
}

/**
 * Fixed storefront header with logo, centered nav and cart.
 * @startingPoint section="Layout" subtitle="Storefront header — transparent-over-hero or solid" viewport="900x90"
 */
export function NavBar(props: NavBarProps): JSX.Element;
