import React from 'react';

export interface FooterColumn {
  heading: string;
  links: string[];
}

export interface FooterProps {
  /** Three link columns (Shop / Customer Care / Info by default) */
  columns?: FooterColumn[];
  copyright?: string;
  onNavigate?: (label: string) => void;
}

export function Footer(props: FooterProps): JSX.Element;
