import React from 'react';

/**
 * Tamar Kfir Jewelry — Badge
 * Small uppercase marker for product status: sale, sold-out, or a
 * soft "Handmade" tag. Sits over imagery (absolute) or inline.
 */
export function Badge({ children, variant = 'neutral', ...rest }) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    fontFamily: 'var(--tk-font-body)',
    fontSize: 'var(--tk-size-caption)',
    fontWeight: 'var(--tk-weight-semibold)',
    letterSpacing: 'var(--tk-track-label)',
    textTransform: 'uppercase',
    padding: '0.35rem 0.7rem',
    lineHeight: 1,
    whiteSpace: 'nowrap',
  };

  const variants = {
    neutral: { background: 'var(--tk-ink)', color: '#fff' },
    gold: { background: 'var(--tk-gold)', color: 'var(--tk-ink)' },
    soft: {
      background: 'var(--tk-gold-tint)',
      color: 'var(--tk-gold-hover)',
    },
    outline: {
      background: 'transparent',
      color: 'var(--tk-text-muted)',
      border: '1px solid var(--tk-border-strong)',
    },
  };

  return (
    <span style={{ ...base, ...variants[variant] }} {...rest}>
      {children}
    </span>
  );
}
