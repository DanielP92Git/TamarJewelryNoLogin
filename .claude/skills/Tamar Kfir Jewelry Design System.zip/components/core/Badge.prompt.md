**Badge** — small uppercase marker for product status (Sale, Sold Out) or a soft "Handmade" tag. Place absolutely over a product image or inline beside a title.

```jsx
<Badge variant="gold">Sale</Badge>
<Badge variant="soft">Handmade</Badge>
<Badge variant="outline">One of a kind</Badge>
```

Variants: `neutral` · `gold` · `soft` · `outline`.
