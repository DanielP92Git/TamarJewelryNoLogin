**PriceTag** — a price with optional struck-through original and gold sale styling. Currency-aware (₪ ILS / $ USD) to match the bilingual storefront.

```jsx
<PriceTag amount={120} />
<PriceTag amount={96} original={120} currency="ILS" size="lg" align="left" />
```

When `original > amount`, the current price turns gold and the original is struck through.
