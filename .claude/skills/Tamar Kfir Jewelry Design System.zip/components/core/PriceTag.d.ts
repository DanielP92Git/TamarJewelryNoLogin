import React from 'react';

export interface PriceTagProps {
  /** Current price (number, no symbol) */
  amount: number;
  /** Optional original price — when higher than amount, shows struck-through + gold sale price */
  original?: number;
  /** ILS → ₪ (default), USD → $ */
  currency?: 'ILS' | 'USD';
  size?: 'sm' | 'md' | 'lg';
  align?: 'left' | 'center' | 'right';
}

export function PriceTag(props: PriceTagProps): JSX.Element;
