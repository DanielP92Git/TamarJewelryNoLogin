import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — Button
 * The brand's action element. Dark "ink" is the default storefront
 * button (square, uppercase). The gold-outline pill is the hero
 * call-to-action over photography. Gold-solid is a softer accent.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  onClick,
  type = 'button',
  ...rest
}) {
  const [hover, setHover] = useState(false);

  const sizes = {
    sm: { padding: '0.6rem 1.4rem', fontSize: '0.7rem' },
    md: { padding: '0.85rem 2rem', fontSize: '0.78rem' },
    lg: { padding: '1.05rem 2.6rem', fontSize: '0.82rem' },
  };

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.6rem',
    fontFamily: 'var(--tk-font-body)',
    fontWeight: 'var(--tk-weight-semibold)',
    letterSpacing: 'var(--tk-track-wide)',
    textTransform: 'uppercase',
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    border: '1px solid transparent',
    transition: 'all var(--tk-dur) var(--tk-ease)',
    width: fullWidth ? '100%' : 'auto',
    opacity: disabled ? 0.45 : 1,
    ...sizes[size],
  };

  const variants = {
    primary: {
      background: hover && !disabled ? 'var(--tk-ink-deep)' : 'var(--tk-ink)',
      color: '#fff',
      borderRadius: 'var(--tk-radius-none)',
    },
    gold: {
      background: hover && !disabled ? 'var(--tk-gold-hover)' : 'var(--tk-gold)',
      color: 'var(--tk-ink)',
      borderRadius: 'var(--tk-radius-none)',
    },
    outline: {
      background: hover && !disabled ? '#fff' : 'rgba(255,255,255,0.96)',
      color: 'var(--tk-gold)',
      borderColor: 'var(--tk-gold)',
      borderRadius: 'var(--tk-radius-pill)',
      transform: hover && !disabled ? 'var(--tk-lift)' : 'none',
      boxShadow: hover && !disabled ? 'var(--tk-shadow-pill)' : 'none',
    },
    ghost: {
      background: 'transparent',
      color: hover && !disabled ? 'var(--tk-text)' : 'var(--tk-text-muted)',
      borderColor: 'transparent',
      borderRadius: 'var(--tk-radius-none)',
      textDecoration: 'underline',
      textUnderlineOffset: '4px',
      textDecorationColor: 'var(--tk-border-strong)',
    },
  };

  return (
    <button
      type={type}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ ...base, ...variants[variant] }}
      {...rest}
    >
      {children}
    </button>
  );
}
