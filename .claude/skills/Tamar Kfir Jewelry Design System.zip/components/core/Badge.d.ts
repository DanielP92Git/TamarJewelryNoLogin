import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  /** neutral = dark ink; gold = solid accent; soft = pale gold wash; outline = hairline tag */
  variant?: 'neutral' | 'gold' | 'soft' | 'outline';
}

export function Badge(props: BadgeProps): JSX.Element;
