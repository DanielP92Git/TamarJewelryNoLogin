**IconButton** — square, borderless icon target for header utilities (cart, hamburger, close) and `circle` social bubbles that fill gold on hover. Always pass a `label`.

```jsx
<IconButton label="Cart"><img src="assets/icons/shopping-bag.svg" /></IconButton>
<IconButton label="Instagram" variant="circle">
  <img src="assets/icons/instagram.svg" />
</IconButton>
```

Variants: `plain` (default) · `circle`. Prop `size` sets the px hit-target (keep ≥ 40 for touch).
