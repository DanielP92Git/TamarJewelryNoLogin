import React from 'react';

export type ButtonVariant = 'primary' | 'gold' | 'outline' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  /** Button label / content */
  children: React.ReactNode;
  /** primary = dark ink (default storefront action); gold = solid accent; outline = gold pill over photography; ghost = underlined text link */
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Stretch to container width (used in cart / modal) */
  fullWidth?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

/**
 * Primary action element for the Tamar Kfir storefront.
 * @startingPoint section="Core" subtitle="Ink, gold, outline-pill and ghost actions" viewport="700x220"
 */
export function Button(props: ButtonProps): JSX.Element;
