**Button** — the storefront's action element; use `primary` (dark ink) for cart/checkout, `outline` (gold pill) as the hero CTA over imagery, `gold` for softer accents, `ghost` for "Remove / Clear" text links.

```jsx
<Button variant="primary" onClick={checkout}>Proceed to Checkout</Button>
<Button variant="outline" size="lg">Discover the Collection</Button>
<Button variant="gold">Add to Cart</Button>
<Button variant="ghost" size="sm">Remove</Button>
```

Variants: `primary` · `gold` · `outline` · `ghost`. Sizes: `sm` · `md` · `lg`. Props: `fullWidth`, `disabled`. All labels render UPPERCASE with wide letter-spacing — pass normal-case text.
