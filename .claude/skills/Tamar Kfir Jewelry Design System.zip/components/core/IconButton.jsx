import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — IconButton
 * Square, borderless icon target for header utilities (cart, menu,
 * close) and social bubbles. Pass an <img>/SVG as children.
 */
export function IconButton({
  children,
  label,
  variant = 'plain',
  size = 40,
  onClick,
  ...rest
}) {
  const [hover, setHover] = useState(false);

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: size,
    height: size,
    padding: 0,
    cursor: 'pointer',
    background: 'transparent',
    border: 'none',
    transition: 'all var(--tk-dur) var(--tk-ease)',
  };

  const variants = {
    plain: {
      opacity: hover ? 1 : 0.78,
    },
    circle: {
      border: '1px solid rgba(168,139,99,0.25)',
      borderRadius: 'var(--tk-radius-round)',
      background: hover ? 'var(--tk-gold)' : '#fff',
      transform: hover ? 'var(--tk-lift)' : 'none',
      boxShadow: hover ? 'var(--tk-shadow-gold)' : 'none',
    },
  };

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ ...base, ...variants[variant] }}
      {...rest}
    >
      <span
        style={{
          display: 'inline-flex',
          width: Math.round(size * 0.45),
          height: Math.round(size * 0.45),
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {children}
      </span>
    </button>
  );
}
