import React from 'react';

/**
 * Tamar Kfir Jewelry — PriceTag
 * Renders a price with optional struck-through original and discount.
 * Currency-aware (₪ / $) to match the bilingual ILS/USD storefront.
 */
export function PriceTag({
  amount,
  original,
  currency = 'ILS',
  size = 'md',
  align = 'center',
}) {
  const symbol = currency === 'USD' ? '$' : '₪';
  const fmt = (n) => `${symbol}${n}`;

  const scale = {
    sm: { now: '1rem', was: '0.8rem' },
    md: { now: '1.2rem', was: '0.9rem' },
    lg: { now: '1.5rem', was: '1rem' },
  }[size];

  const onSale = original != null && original > amount;

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'baseline',
        justifyContent:
          align === 'left' ? 'flex-start' : align === 'right' ? 'flex-end' : 'center',
        gap: '0.6rem',
        fontFamily: 'var(--tk-font-body)',
      }}
    >
      <span
        style={{
          fontSize: scale.now,
          fontWeight: 'var(--tk-weight-semibold)',
          color: onSale ? 'var(--tk-gold-hover)' : 'var(--tk-text)',
          letterSpacing: 'var(--tk-track-tight)',
        }}
      >
        {fmt(amount)}
      </span>
      {onSale && (
        <span
          style={{
            fontSize: scale.was,
            color: 'var(--tk-text-faint)',
            textDecoration: 'line-through',
            opacity: 0.7,
          }}
        >
          {fmt(original)}
        </span>
      )}
    </div>
  );
}
