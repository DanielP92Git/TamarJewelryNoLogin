import React from 'react';

export interface IconButtonProps {
  /** An <img> or inline SVG icon */
  children: React.ReactNode;
  /** Accessible label (also the tooltip) */
  label: string;
  /** plain = bare header icon; circle = bordered social bubble that fills gold on hover */
  variant?: 'plain' | 'circle';
  /** Square hit-target size in px (default 40) */
  size?: number;
  onClick?: () => void;
}

export function IconButton(props: IconButtonProps): JSX.Element;
