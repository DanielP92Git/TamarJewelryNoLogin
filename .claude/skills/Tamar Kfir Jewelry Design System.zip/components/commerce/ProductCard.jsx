import React, { useState } from 'react';
import { PriceTag } from '../core/PriceTag.jsx';
import { Badge } from '../core/Badge.jsx';

/**
 * Tamar Kfir Jewelry — ProductCard
 * The storefront grid tile: beige card, square photo, centered
 * title, price, and a full-width dark "Add to Cart" bar. Lifts on
 * hover. Optional sale badge over the image.
 */
export function ProductCard({
  image,
  title,
  price,
  original,
  currency = 'ILS',
  badge,
  addLabel = 'Add to Cart',
  onAdd,
  onClick,
}) {
  const [hover, setHover] = useState(false);
  const [btnHover, setBtnHover] = useState(false);

  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onClick={onClick}
      style={{
        width: '20rem',
        maxWidth: '100%',
        display: 'flex',
        flexDirection: 'column',
        background: 'var(--tk-surface-beige)',
        borderRadius: 'var(--tk-radius-sm)',
        overflow: 'hidden',
        cursor: 'pointer',
        boxShadow: hover ? 'var(--tk-shadow-card-hover)' : 'var(--tk-shadow-card)',
        transform: hover ? 'var(--tk-lift)' : 'none',
        transition: 'transform var(--tk-dur-fast) var(--tk-ease), box-shadow var(--tk-dur-fast) var(--tk-ease)',
        fontFamily: 'var(--tk-font-body)',
      }}
    >
      <div style={{ position: 'relative', width: '100%', height: '20rem', overflow: 'hidden', background: 'var(--tk-surface)' }}>
        <img
          src={image}
          alt={title}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
            transform: hover ? 'scale(1.04)' : 'scale(1)',
            transition: 'transform var(--tk-dur-slow) var(--tk-ease)',
          }}
        />
        {badge && (
          <div style={{ position: 'absolute', top: '0.85rem', left: '0.85rem' }}>
            <Badge variant="gold">{badge}</Badge>
          </div>
        )}
      </div>

      <div style={{ padding: '1rem 0.75rem 0.5rem', textAlign: 'center' }}>
        <h3
          style={{
            margin: 0,
            fontSize: 'var(--tk-size-title)',
            fontWeight: 'var(--tk-weight-medium)',
            color: 'var(--tk-text)',
            lineHeight: 'var(--tk-leading-snug)',
          }}
        >
          {title}
        </h3>
      </div>

      <div style={{ margin: '0.25rem 0 0.85rem' }}>
        <PriceTag amount={price} original={original} currency={currency} size="md" align="center" />
      </div>

      <button
        type="button"
        onClick={(e) => { e.stopPropagation(); onAdd && onAdd(); }}
        onMouseEnter={() => setBtnHover(true)}
        onMouseLeave={() => setBtnHover(false)}
        style={{
          width: '90%',
          margin: '0 auto 1rem',
          height: 40,
          border: 'none',
          background: btnHover ? 'var(--tk-ink-deep)' : 'var(--tk-ink)',
          color: '#fff',
          fontFamily: 'var(--tk-font-body)',
          fontSize: '0.78rem',
          fontWeight: 'var(--tk-weight-semibold)',
          letterSpacing: 'var(--tk-track-label)',
          textTransform: 'uppercase',
          cursor: 'pointer',
          transition: 'background var(--tk-dur) var(--tk-ease)',
        }}
      >
        {addLabel}
      </button>
    </div>
  );
}
