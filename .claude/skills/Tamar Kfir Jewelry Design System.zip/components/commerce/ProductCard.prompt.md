**ProductCard** — the storefront grid tile: beige card, square photo (zooms on hover), centered title, price, and a dark full-width "Add to Cart" bar. Composes `PriceTag` and `Badge`.

```jsx
<ProductCard
  image="assets/products/crochet-01.jpg"
  title="True Colors Crochet Necklace"
  price={450}
  badge="Handmade"
  onAdd={() => addToCart(id)}
  onClick={() => openProduct(id)}
/>
```

Pass `original` (a higher number) to show a sale price. Fixed 20rem width — drop into a flex-wrap grid.
