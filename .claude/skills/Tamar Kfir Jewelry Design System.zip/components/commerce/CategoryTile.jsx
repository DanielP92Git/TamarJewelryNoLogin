import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — CategoryTile
 * Full-bleed photo with a bottom protection scrim and a centered,
 * wide-tracked uppercase label. Letter-spacing opens slightly on
 * hover — the brand's signature category treatment.
 */
export function CategoryTile({ image, label, href = '#', height = 280, onClick }) {
  const [hover, setHover] = useState(false);

  return (
    <a
      href={href}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        display: 'block',
        height,
        overflow: 'hidden',
        borderRadius: 'var(--tk-radius-sm)',
        textDecoration: 'none',
        transform: hover ? 'translateY(-4px)' : 'none',
        transition: 'transform var(--tk-dur) var(--tk-ease)',
      }}
    >
      <img
        src={image}
        alt={label}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          display: 'block',
          transform: hover ? 'scale(1.05)' : 'scale(1)',
          transition: 'transform var(--tk-dur-slow) var(--tk-ease)',
        }}
      />
      <span
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          alignItems: 'flex-end',
          justifyContent: 'center',
          padding: '2.5rem 1.5rem 1.5rem',
          background: 'var(--tk-scrim-bottom)',
          color: '#fff',
          fontFamily: 'var(--tk-font-display)',
          fontWeight: 'var(--tk-weight-light)',
          fontSize: 'clamp(0.9rem, 1.2vw, 1.1rem)',
          letterSpacing: hover ? '0.3em' : 'var(--tk-track-hero)',
          textTransform: 'uppercase',
          textShadow: '0 2px 12px rgba(0,0,0,0.5)',
          textAlign: 'center',
          transition: 'letter-spacing var(--tk-dur-slow) var(--tk-ease)',
        }}
      >
        {label}
      </span>
    </a>
  );
}
