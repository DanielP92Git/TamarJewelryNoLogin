**CategoryTile** — full-bleed category photo with a bottom protection scrim and a centered, wide-tracked uppercase label. Letter-spacing opens on hover — the brand's signature collection treatment. Use in a 2-up or 4-up grid on the home page.

```jsx
<CategoryTile image="assets/categories/crochet.webp" label="Crochet Necklaces" href="/crochet" />
```
