import React from 'react';

export interface ProductCardProps {
  /** Product photo URL (square crop) */
  image: string;
  title: string;
  /** Current price (number) */
  price: number;
  /** Optional original price for sale styling */
  original?: number;
  currency?: 'ILS' | 'USD';
  /** Optional corner badge text, e.g. "Sale" */
  badge?: string;
  /** Cart button label (default "Add to Cart"); pass a localized string for RTL/Hebrew */
  addLabel?: string;
  /** Fired by the Add to Cart bar */
  onAdd?: () => void;
  /** Fired when the card body is clicked (open detail) */
  onClick?: () => void;
}

/**
 * Storefront product grid tile.
 * @startingPoint section="Commerce" subtitle="Beige product card with photo, price and add-to-cart" viewport="700x520"
 */
export function ProductCard(props: ProductCardProps): JSX.Element;
