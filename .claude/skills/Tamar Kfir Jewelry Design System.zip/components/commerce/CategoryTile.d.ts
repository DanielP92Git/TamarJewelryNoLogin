import React from 'react';

export interface CategoryTileProps {
  /** Full-bleed category photo */
  image: string;
  /** Uppercase label rendered over the bottom scrim */
  label: string;
  href?: string;
  /** Tile height in px (default 280) */
  height?: number;
  onClick?: (e: React.MouseEvent) => void;
}

export function CategoryTile(props: CategoryTileProps): JSX.Element;
