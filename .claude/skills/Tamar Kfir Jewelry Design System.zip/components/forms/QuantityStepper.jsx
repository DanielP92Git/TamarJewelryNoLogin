import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — QuantityStepper
 * Bordered − [n] + control used in the cart. Sharp corners,
 * hairline border, hover-grey on the buttons.
 */
export function QuantityStepper({
  value,
  defaultValue = 1,
  min = 1,
  max = 99,
  onChange,
  width = 110,
}) {
  const controlled = value != null;
  const [internal, setInternal] = useState(defaultValue);
  const [hovered, setHovered] = useState(null); // 'dec' | 'inc' | null
  const qty = controlled ? value : internal;

  const set = (next) => {
    const clamped = Math.max(min, Math.min(max, next));
    if (!controlled) setInternal(clamped);
    onChange && onChange(clamped);
  };

  const btnStyle = (key, disabled) => ({
    width: 34,
    height: 38,
    border: 'none',
    background: hovered === key && !disabled ? 'var(--tk-surface)' : 'transparent',
    color: disabled ? 'var(--tk-text-faint)' : 'var(--tk-text-muted)',
    fontSize: '1rem',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'background var(--tk-dur-fast) var(--tk-ease)',
    fontFamily: 'var(--tk-font-body)',
  });

  return (
    <div
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        width,
        border: '1px solid var(--tk-border-strong)',
        borderRadius: 'var(--tk-radius-none)',
        fontFamily: 'var(--tk-font-body)',
      }}
    >
      <button
        type="button"
        disabled={qty <= min}
        onClick={() => set(qty - 1)}
        onMouseEnter={() => setHovered('dec')}
        onMouseLeave={() => setHovered(null)}
        style={btnStyle('dec', qty <= min)}
      >
        −
      </button>
      <span
        style={{
          flex: 1,
          textAlign: 'center',
          fontSize: 'var(--tk-size-small)',
          color: 'var(--tk-text)',
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {qty}
      </span>
      <button
        type="button"
        disabled={qty >= max}
        onClick={() => set(qty + 1)}
        onMouseEnter={() => setHovered('inc')}
        onMouseLeave={() => setHovered(null)}
        style={btnStyle('inc', qty >= max)}
      >
        +
      </button>
    </div>
  );
}
