import React from 'react';

export interface InputProps {
  /** Uppercase field label rendered above the input */
  label?: string;
  type?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  fullWidth?: boolean;
  id?: string;
}

export function Input(props: InputProps): JSX.Element;
