import React from 'react';

export interface QuantityStepperProps {
  /** Controlled quantity. Omit to use defaultValue (uncontrolled). */
  value?: number;
  defaultValue?: number;
  min?: number;
  max?: number;
  onChange?: (next: number) => void;
  /** Overall pixel width (default 110) */
  width?: number;
}

export function QuantityStepper(props: QuantityStepperProps): JSX.Element;
