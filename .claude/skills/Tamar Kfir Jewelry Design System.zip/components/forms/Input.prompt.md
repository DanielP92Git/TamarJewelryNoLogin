**Input** — quiet text field for contact forms and the newsletter sign-up. Optional uppercase label, gold focus ring, sharp 4px corners.

```jsx
<Input label="Email" type="email" placeholder="you@example.com" />
<Input label="Name" placeholder="Your name" />
```
