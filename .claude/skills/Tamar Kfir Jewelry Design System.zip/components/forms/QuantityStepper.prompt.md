**QuantityStepper** — bordered `− [n] +` control for the cart. Works controlled (`value` + `onChange`) or uncontrolled (`defaultValue`). Clamps between `min` and `max`.

```jsx
<QuantityStepper defaultValue={1} min={1} max={10} onChange={(n) => update(n)} />
```
