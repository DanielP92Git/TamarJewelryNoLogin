import React, { useState } from 'react';

/**
 * Tamar Kfir Jewelry — Input
 * Quiet text field for contact forms and newsletter sign-up.
 * Optional uppercase label; gold focus ring; sharp corners.
 */
export function Input({
  label,
  type = 'text',
  placeholder,
  value,
  defaultValue,
  onChange,
  fullWidth = true,
  id,
  ...rest
}) {
  const [focus, setFocus] = useState(false);

  return (
    <label
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '0.5rem',
        width: fullWidth ? '100%' : 'auto',
        fontFamily: 'var(--tk-font-body)',
      }}
    >
      {label && (
        <span
          style={{
            fontSize: 'var(--tk-size-label)',
            fontWeight: 'var(--tk-weight-medium)',
            letterSpacing: 'var(--tk-track-label)',
            textTransform: 'uppercase',
            color: 'var(--tk-text-muted)',
          }}
        >
          {label}
        </span>
      )}
      <input
        id={id}
        type={type}
        placeholder={placeholder}
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          width: '100%',
          boxSizing: 'border-box',
          padding: '0.85rem 1rem',
          fontFamily: 'var(--tk-font-body)',
          fontSize: 'var(--tk-size-body)',
          color: 'var(--tk-text)',
          background: 'var(--tk-white)',
          border: `1px solid ${focus ? 'var(--tk-gold)' : 'var(--tk-border-strong)'}`,
          borderRadius: 'var(--tk-radius-xs)',
          outline: 'none',
          boxShadow: focus ? '0 0 0 3px rgba(197,165,114,0.12)' : 'none',
          transition: 'border-color var(--tk-dur) var(--tk-ease), box-shadow var(--tk-dur) var(--tk-ease)',
        }}
        {...rest}
      />
    </label>
  );
}
